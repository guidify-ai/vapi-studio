import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { looksLikeProjectTimeline } from '../../lib/estimate-parse';

/** Instant estimate Q1 — project timeline. */
@Injectable()
export class AskTimelineNode extends Ra9Node<RoofrConversationSchema> {
  /** Timeline answers often arrive as "K." then the real phrase. */
  listenTimeoutSeconds = 3.5;
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isCollectedTimeline', boost: 20 }, ...portalBoosts()],
      hints: [
        'Caller answers timeline: ASAP, this month, next season, etc.',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const text = ctx.userText.toLowerCase();
    ctx.memory.wantsInstantEstimate = /\b(yes|yeah|yep|sure|ok|okay)\b/.test(
      text,
    );
    return ctx.output.sayAndListen(
      "What's the timeline for your project?",
      {
        extract: {
          fields: [
            {
              key: 'timeline',
              type: 'string',
              required: true,
              description: 'Project timeline',
            },
          ],
          onExtracted: (_data, apply) => {
            const v = apply.userText.trim();
            if (looksLikeProjectTimeline(v)) ctx.memory.projectTimeline = v;
          },
        },
      },
    );
  }
}
