import type { CheapOpenAiModelId } from '@guidify-ai/ra9';

/**
 * Brain wiring for this app. Change here — not in .env.
 *
 * Cheap whitelist only: gpt-4.1-nano (default), gpt-4o-mini, gpt-4.1-mini, gpt-5.4-nano.
 * Live driver: `ra9-chatgpt` (ChatGptBrainAdapter). Mock sequences are unused
 * on the live path while this is set. Requires OPENAI_API_KEY in `.env`.
 * Experiment: gpt-4.1-mini (smarter, usually slower than nano). Flip back to
 * gpt-4.1-nano if first speech misses the 1.5s target or scan hits the 3s abort.
 */
export const brainConfig = {
  adapter: 'ra9-chatgpt' as 'mock' | 'ra9-chatgpt' | 'roofr',
  model: 'gpt-4.1-mini' as CheapOpenAiModelId,
  confidenceThreshold: 0.4,
};
