import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ConversationEntity } from './conversation.entity';
import { ConversationEventEntity } from './conversation-event.entity';
import type { ConversationStatus } from '../conversation/types';

@Injectable()
export class ConversationRepository {
  constructor(
    @InjectRepository(ConversationEntity)
    private readonly conversations: Repository<ConversationEntity>,
    @InjectRepository(ConversationEventEntity)
    private readonly events: Repository<ConversationEventEntity>,
  ) {}

  createActive(input: {
    providerCallId: string;
    runtimeInstanceId: string;
    metadata?: Record<string, unknown>;
    provider?: string;
  }): Promise<ConversationEntity> {
    const row = this.conversations.create({
      provider: input.provider ?? 'vapi',
      providerCallId: input.providerCallId,
      status: 'ACTIVE',
      runtimeInstanceId: input.runtimeInstanceId,
      metadata: input.metadata ?? {},
      endedAt: null,
      finalState: null,
    });
    return this.conversations.save(row);
  }

  findByProviderCallId(
    providerCallId: string,
  ): Promise<ConversationEntity | null> {
    return this.conversations.findOne({ where: { providerCallId } });
  }

  async markEnded(input: {
    conversationId: string;
    finalState: Record<string, unknown>;
  }): Promise<void> {
    const row = await this.conversations.findOneByOrFail({
      id: input.conversationId,
    });
    row.status = 'ENDED';
    row.endedAt = new Date();
    row.finalState = input.finalState;
    await this.conversations.save(row);
  }

  async appendEvent(input: {
    conversationId: string;
    type: string;
    payload?: Record<string, unknown>;
  }): Promise<void> {
    const row = this.events.create({
      conversationId: input.conversationId,
      type: input.type,
      payload: input.payload ?? {},
    });
    await this.events.save(row);
  }
}
