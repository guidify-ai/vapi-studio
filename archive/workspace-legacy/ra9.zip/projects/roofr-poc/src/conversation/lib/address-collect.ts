import {
  isClarifyCannotAnswerError,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';
import { portalBoosts } from './portal-boosts';
import {
  ADDRESS_LISTEN_TIMEOUT_SECONDS,
  looksLikeNorthAmericanAddress,
} from './estimate-parse';

export { ADDRESS_LISTEN_TIMEOUT_SECONDS };

const ADDRESS_PROMPT =
  "What's the address of the property you'd like estimated? Number, street, city, and province or state.";

export function addressCollectListen(): ListenExpectation {
  return {
    timeoutSeconds: ADDRESS_LISTEN_TIMEOUT_SECONDS,
    interruptible: false,
    intentions: [{ name: 'isCollectedAddress', boost: 20 }, ...portalBoosts()],
    hints: [
      'Caller is dictating a Canadian or US property address: house number, street, city, province or state.',
      'Spoken digits like "1 2 3 Main Street Toronto Ontario" still count. Names and yes/no are not addresses.',
    ],
  };
}

export async function reaskAddress(
  ctx: NodeContext<RoofrConversationSchema>,
): Promise<NodeResult> {
  return ctx.output.sayAndListen(ADDRESS_PROMPT, {
    ...addressCollectListen(),
    extract: {
      fields: [
        {
          key: 'address',
          type: 'string',
          required: true,
          description: 'Property street address as spoken',
        },
      ],
      onExtracted: (data, apply) => {
        const addr =
          typeof data.address === 'string' && data.address.trim()
            ? data.address.trim()
            : apply.userText.trim();
        if (addr) ctx.memory.addressQuery = addr;
      },
    },
  });
}

/**
 * Number–street–city–province/state (CA/US). Cheap shape first; Brain.clarify
 * only when the utterance is borderline. Re-ask if it is not an address.
 */
export async function confirmLooksLikeAddress(
  ctx: NodeContext<RoofrConversationSchema>,
  query: string,
): Promise<{ ok: boolean; normalized: string }> {
  if (looksLikeNorthAmericanAddress(query)) {
    return { ok: true, normalized: query };
  }

  await ctx.output.say(
    'Let me make sure I heard that address correctly.',
  );

  try {
    const { answer } = await ctx.clarify<{
      looksLikeAddress?: boolean | string;
      normalized?: string | null;
    }>({
      input: query,
      question:
        'Does this utterance look like a Canadian or US street address (house number, street name, city, province or state)? Spoken digits like "1 2 3" are the house number. A person name, yes/no, or phone confirmation is NOT an address.',
      answer: {
        description: 'Whether the collected speech is a CA/US civic address',
        fields: [
          {
            key: 'looksLikeAddress',
            type: 'boolean',
            required: true,
            description: 'True if it has enough of number, street, city, province/state to look up',
          },
          {
            key: 'normalized',
            type: 'string',
            required: false,
            description:
              'Tidied address when looksLikeAddress is true, e.g. 123 Main Street, Toronto, Ontario',
          },
        ],
      },
    });
    const ok =
      answer.looksLikeAddress === true || answer.looksLikeAddress === 'true';
    const normalized =
      typeof answer.normalized === 'string' && answer.normalized.trim()
        ? answer.normalized.trim()
        : query;
    return { ok, normalized };
  } catch (error) {
    if (isClarifyCannotAnswerError(error)) {
      return { ok: false, normalized: query };
    }
    throw error;
  }
}
