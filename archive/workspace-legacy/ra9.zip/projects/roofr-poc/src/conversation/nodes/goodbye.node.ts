import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

/** Closing — thanks + endCall tool. */
@Injectable()
export class GoodbyeNode extends Ra9Node<RoofrConversationSchema> {
  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const name = ctx.memory.firstName;
    const thanks = name
      ? `Thanks for calling, ${name}. Goodbye.`
      : 'Thanks for calling. Goodbye.';
    return ctx.output.endCall(thanks);
  }
}
