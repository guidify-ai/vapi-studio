import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from 'typeorm';
import type { ConversationStatus } from '../conversation/types';

@Entity({ name: 'conversations' })
export class ConversationEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column({ type: 'varchar', length: 64, default: 'vapi' })
  provider!: string;

  @Index({ unique: true })
  @Column({ name: 'provider_call_id', type: 'varchar', length: 128 })
  providerCallId!: string;

  @Column({ type: 'varchar', length: 32, default: 'ACTIVE' })
  status!: ConversationStatus;

  @Column({
    name: 'runtime_instance_id',
    type: 'varchar',
    length: 64,
    nullable: true,
  })
  runtimeInstanceId!: string | null;

  @Column({ type: 'jsonb', default: {} })
  metadata!: Record<string, unknown>;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' })
  createdAt!: Date;

  @Column({ name: 'ended_at', type: 'timestamptz', nullable: true })
  endedAt!: Date | null;

  @Column({ name: 'final_state', type: 'jsonb', nullable: true })
  finalState!: Record<string, unknown> | null;
}
