export const RA9_INTENTIONS = {
  isGoodbye: 'ra9.isGoodbye',
  isTransferToHuman: 'ra9.isTransferToHuman',
  isPause: 'ra9.isPause',
  /** Caller is angry / mad — handle as a standalone portal, not normal flow. */
  isMad: 'ra9.isMad',
  /**
   * No candidate intention cleared the confidence threshold.
   * Standalone portal — ask to clarify / recover.
   */
  isUnknownTransition: 'ra9.isUnknownTransition',
  /** Affirmative answer (yes / correct / sure / okay). */
  isPositive: 'ra9.isPositive',
  /** Negative answer (no / incorrect / decline). */
  isNegative: 'ra9.isNegative',
} as const;

export type Ra9StandardIntention =
  (typeof RA9_INTENTIONS)[keyof typeof RA9_INTENTIONS];
