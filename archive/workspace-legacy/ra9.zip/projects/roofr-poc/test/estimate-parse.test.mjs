import assert from 'node:assert/strict';
import test from 'node:test';
import { createRequire } from 'node:module';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const { looksLikeNorthAmericanAddress, collectedPersonName, parseListedChoice } = require(
  join(root, 'dist/conversation/lib/estimate-parse.js'),
);
const { listedChoiceQuestion, LISTED_CHOICE_CLOSER } = require(
  join(root, 'dist/conversation/lib/listed-choice-listen.js'),
);

test('looksLikeNorthAmericanAddress: CA/US number-street-city', () => {
  assert.equal(
    looksLikeNorthAmericanAddress('123 main street toronto'),
    true,
  );
  assert.equal(
    looksLikeNorthAmericanAddress(
      "It's 1 2 3 Main Street, Toronto, Ontario",
    ),
    true,
  );
  assert.equal(looksLikeNorthAmericanAddress('k u m OV.'), false);
  assert.equal(looksLikeNorthAmericanAddress('Pyskunov'), false);
  assert.equal(looksLikeNorthAmericanAddress('Yes. It is.'), false);
});

test('collectedPersonName prefers extract over filler ASR', () => {
  assert.equal(collectedPersonName('Peter', 'Sure'), 'Peter');
  assert.equal(collectedPersonName('Peter', 'my name is Peter'), 'Peter');
  assert.equal(collectedPersonName('', 'Peter'), 'Peter');
  assert.equal(collectedPersonName('Sure', 'Peter'), 'Peter');
});

test('parseListedChoice: ordinal pick or neither', () => {
  const matches = [
    { label: '123 Main Street, Toronto, Ontario' },
    { label: '3123 Main Street, Toronto, Ontario' },
  ];
  assert.deepEqual(parseListedChoice('It is the first option.', matches), {
    kind: 'pick',
    index: 0,
  });
  assert.deepEqual(parseListedChoice('It did the first 1.', matches), {
    kind: 'pick',
    index: 0,
  });
  assert.deepEqual(parseListedChoice('first one', matches), {
    kind: 'pick',
    index: 0,
  });
  assert.deepEqual(parseListedChoice('the second one', matches), {
    kind: 'pick',
    index: 1,
  });
  assert.deepEqual(parseListedChoice('neither', matches), { kind: 'reject' });
  assert.deepEqual(parseListedChoice('none of those', matches), {
    kind: 'reject',
  });
  assert.equal(parseListedChoice('yep', matches), null);
});

test('listedChoiceQuestion is always numbered plus the same closer', () => {
  const text = listedChoiceQuestion('I have several openings:', [
    '9am',
    '10am',
    '11am',
  ]);
  assert.match(text, /^I have several openings: 1\) 9am, and 2\) 10am, and 3\) 11am\. /);
  assert.ok(text.endsWith(LISTED_CHOICE_CLOSER));
  assert.equal(
    parseListedChoice('moderate', [
      'steep',
      'a moderate slope',
      'rocky mountain',
    ])?.index,
    1,
  );
});
