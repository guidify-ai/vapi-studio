# RA9 projects

This folder holds **installable NestJS applications** built on Guidify AI packages. It is not a catalog of every bot.

Each application is its own git repo, cloned into `projects/<name>/`. The workspace (`rA9-workspace`) only teaches layout and how to add the next one.

## Guidify AI packages apps may use

Update **this table** whenever a package is added, removed, renamed, or the consume path changes.

| Package | Path in this workspace | npm name | GitHub repo |
| --- | --- | --- | --- |
| RA9 conversation framework | `packages/ra9` | `@guidify-ai/ra9` | [pyskunov/rA9-framework](https://github.com/pyskunov/rA9-framework) |

Apps depend through Yarn `file:` (or a later private registry), never by importing framework source files.

```json
{
  "dependencies": {
    "@guidify-ai/ra9": "file:../../packages/ra9"
  }
}
```

Framework contracts: [`packages/ra9/README.md`](../packages/ra9/README.md).

## How to have a project

1. **Create a repo** named `rA9-project-<short-name>` (example: `rA9-project-roofr-poc`).
2. **Clone it here** as `projects/<short-name>/` so the `file:../../packages/ra9` path stays valid.
3. **Scaffold a NestJS app** that:
   - imports `Ra9Module.forRoot({ nodes, entryPoint, brainAdapter })` from `@guidify-ai/ra9`
   - owns `config/flow.yaml`, Node classes, conversation variables/memory, Brain choice, Docker Compose, `.env.example`, and a `logs/` folder for daily call files
   - exposes channel HTTP (Vapi webhook + Custom LLM for the current PoC) without putting provider wire format inside Nodes
4. **Run in Docker.** Host Node is not required for the app. Postgres via Compose. Operator-owned secrets stay in `.env` (never committed).
5. **Write `README.md` in the project** with northern stars (below). Do **not** paste flow YAML, node graphs, or listen extract schemas into that README.

### Expected shape (convention, not a generator)

```text
projects/<name>/
├── README.md                 northern stars + how to run
├── package.json              @guidify-ai/ra9 via file:
├── docker-compose.yml
├── Dockerfile
├── .env.example
├── logs/                     dailyYYYYMMDD.log (gitignored files; folder stays)
├── config/flow.yaml          conversation paths only
├── src/
│   ├── app.module.ts
│   ├── conversation/         Nodes, variables, entry point
│   ├── vapi/                 (or later channel adapters)
│   └── ...
└── test/
```

### What belongs in the app vs the framework

| App owns | Framework owns |
| --- | --- |
| Flow YAML, Node classes, copy, domain services | Supervisor, `Ra9Node` contracts, Brain port |
| Use-case intentions and portal Node **behavior** | Standard intention **names** (`ra9.isGoodbye`, …) |
| Channel wiring for this deployment | Vapi SSE compiler / call-id helpers |
| `.env` keys, `logs/` (daily call files) | Persistence entities, events, log *driver* (writes where the app points `LOG_DIR`) |

## Project README (northern stars)

Every project README must answer:

- **Why this app exists** (one or two stars, not a feature dump)
- **What “done” looks like** for the current experiment or product slice
- **Triggers** that force a README update (goal change, new channel, Brain default change, portal policy change, success criteria change)

Do not document the conversation design in the README. That lives in `config/flow.yaml` and Node source.

When those stars or their triggers change, update the project README in the **same** change.
