import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { collectedPersonName } from '../../lib/estimate-parse';

/** After first name — ask last name. */
@Injectable()
export class AskLastNameNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isCollectedLastName', boost: 20 }, ...portalBoosts()],
      hints: ['Caller is answering with their last name / family name.'],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const first = ctx.memory.firstName?.trim();
    const thanks = first
      ? `Thanks, ${first}. And your last name?`
      : 'Thanks. And your last name?';
    return ctx.output.sayAndListen(thanks, {
      extract: {
        fields: [
          {
            key: 'lastName',
            type: 'string',
            required: true,
            description: 'Caller last name',
          },
        ],
        onExtracted: (data, apply) => {
          const name = collectedPersonName(data.lastName, apply.userText);
          if (name) {
            ctx.memory.lastName = name;
          }
        },
      },
    });
  }
}
