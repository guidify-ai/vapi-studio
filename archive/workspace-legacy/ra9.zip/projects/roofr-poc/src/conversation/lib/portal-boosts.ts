import { RA9_INTENTIONS, type ListenIntentionBoost } from '@guidify-ai/ra9';

/** Standard portal boosts shared by estimate Nodes. */
export function portalBoosts(): ListenIntentionBoost[] {
  return [
    { name: RA9_INTENTIONS.isMad, boost: 15 },
    { name: RA9_INTENTIONS.isTransferToHuman, boost: 8 },
    { name: RA9_INTENTIONS.isPause, boost: 5 },
    { name: RA9_INTENTIONS.isGoodbye, boost: 3 },
  ];
}
