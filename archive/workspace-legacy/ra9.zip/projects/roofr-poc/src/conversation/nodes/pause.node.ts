import { Injectable } from '@nestjs/common';
import { Ra9Node, type NodeContext, type NodeResult } from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

@Injectable()
export class PauseNode extends Ra9Node<RoofrConversationSchema> {
  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    await ctx.events.persist(ctx.runtime.conversationId, 'PAUSE_ENTER', {
      runtimeInstanceId: ctx.runtime.runtimeInstanceId,
      originNodeId: ctx.runtime.portalState.originNodeId,
      activePortalId: ctx.runtime.portalState.activePortalId,
    });
    return ctx.output.sayAndListen('Sure, take your time. Okay?');
  }
}
