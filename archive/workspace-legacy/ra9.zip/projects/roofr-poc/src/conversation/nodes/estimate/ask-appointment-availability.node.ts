import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';

/**
 * Caller said yes to booking — ask when they are available (before checking slots).
 */
@Injectable()
export class AskAppointmentAvailabilityNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isRequestedAppointment', boost: 20 },
        ...portalBoosts(),
      ],
      hints: [
        'Caller says when they want an appointment (e.g. tomorrow, Friday morning).',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    ctx.memory.wantsAppointment = true;
    return ctx.output.sayAndListen(
      'Great — what day or time works best for you?',
    );
  }
}
