import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import {
  ADDRESS_LISTEN_TIMEOUT_SECONDS,
  addressCollectListen,
} from '../../lib/address-collect';

/** Ask for the property address (after phone confirm). Uninterruptible dictation. */
@Injectable()
export class PromptAddressNode extends Ra9Node<RoofrConversationSchema> {
  listenTimeoutSeconds = ADDRESS_LISTEN_TIMEOUT_SECONDS;
  interruptible = false;
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return addressCollectListen();
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    return ctx.output.sayAndListen(
      "Great. What's the address of the property you'd like estimated? Number, street, city, and province or state.",
      {
        ...addressCollectListen(),
        extract: {
          fields: [
            {
              key: 'address',
              type: 'string',
              required: true,
              description: 'Property street address as spoken',
            },
          ],
          onExtracted: (data, apply) => {
            const addr =
              typeof data.address === 'string' && data.address.trim()
                ? data.address.trim()
                : apply.userText.trim();
            if (addr) ctx.memory.addressQuery = addr;
          },
        },
      },
    );
  }
}
