import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { looksLikeRoofSlope, parseListedChoice } from '../../lib/estimate-parse';
import {
  clearListedChoice,
  openListedChoice,
  SLOPE_CHOICE_LABELS,
} from '../../lib/listed-choice-listen';
import { computeInstantEstimate } from '../../../integrations/mock-roofr.integration';

function applySlopeFromChoice(
  ctx: NodeContext<RoofrConversationSchema>,
  spoken: string,
): boolean {
  const labels = ctx.memory.listedChoice?.labels ?? [...SLOPE_CHOICE_LABELS];
  const parsed = parseListedChoice(spoken, labels);
  if (parsed?.kind === 'pick') {
    ctx.memory.roofSlope = labels[parsed.index];
    return true;
  }
  if (looksLikeRoofSlope(spoken)) {
    ctx.memory.roofSlope = spoken;
    return true;
  }
  return looksLikeRoofSlope(ctx.memory.roofSlope ?? '');
}

function slopeChoice(ctx: NodeContext<RoofrConversationSchema>) {
  return openListedChoice(ctx, {
    intro: 'I have several options:',
    labels: [...SLOPE_CHOICE_LABELS],
    pickIntention: 'isCollectedSlope',
    rejectIntention: 'isRejectedSlope',
  });
}

/** Deliver estimate range and ask if they have other questions. */
@Injectable()
export class DeliverEstimateNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isAnsweredOtherQuestions', boost: 15 },
        { name: 'ra9.isGoodbye', boost: 10 },
        ...portalBoosts(),
      ],
      hints: [
        'No / nothing else → closing. Yes → they may ask another question.',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const spoken = ctx.userText.trim();
    if (!applySlopeFromChoice(ctx, spoken)) {
      ctx.runtime.brainSequenceIndex = Math.max(
        0,
        ctx.runtime.brainSequenceIndex - 1,
      );
      const choice = slopeChoice(ctx);
      return ctx.output.sayAndListen(choice.text, {
        ...choice.listen,
        timeoutSeconds: 3.5,
      });
    }

    clearListedChoice(ctx);
    const range = computeInstantEstimate({
      timeline: ctx.memory.projectTimeline,
      roofSlope: ctx.memory.roofSlope,
    });
    ctx.memory.estimateLow = range.low;
    ctx.memory.estimateHigh = range.high;

    const lowK = Math.round(range.low / 1000);
    const highK = Math.round(range.high / 1000);
    await ctx.output.say(
      `Based on what you told me, your estimate is between ${lowK} and ${highK} thousand dollars.`,
    );
    return ctx.output.sayAndListen('Do you have any other questions?');
  }
}
