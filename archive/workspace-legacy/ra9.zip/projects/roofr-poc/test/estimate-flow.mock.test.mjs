/**
 * Roofr estimate call-flow proof (mocked Brain + no network APIs).
 */
import assert from 'node:assert/strict';
import { describe, it, beforeEach, mock } from 'node:test';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, '..');
const ra9Root = join(root, '../../packages/ra9');

// Prefer freshly built RA9 dist (file: link can be stale in the test container).
function loadRa9(pathFromDist) {
  return require(join(ra9Root, 'dist', pathFromDist));
}

function load(pathFromSrc) {
  return require(join(root, 'dist', pathFromSrc));
}

describe('Roofr estimate flow (MockBrain)', () => {
  beforeEach(() => {
    process.env.OPENAI_API_KEY = 'sk-mock-not-real';
    process.env.VAPI_END_CALL_TOOL_NAME = 'end_call_tool';
    process.env.POC_COMPANY_NAME = 'Roofr';
  });

  it('runs intro → estimate → intake → book → email → instant → goodbye', async () => {
    const { MockBrainAdapter } = loadRa9('brain/adapters/mock-brain.adapter.js');
    const { SupervisedConversation } = loadRa9(
      'conversation/supervised-conversation.js',
    );
    const { FlowLoader } = loadRa9('flow/flow-loader.js');
    const { Supervisor } = loadRa9('supervisor/supervisor.js');
    const { VapiSseCompiler } = loadRa9(
      'adapters/vapi/vapi-sse.compiler.js',
    );

    const { AcknowledgeNode } = load('conversation/nodes/acknowledge.node.js');
    const { RoofEstimateIntentNode } = load(
      'conversation/nodes/estimate/roof-estimate-intent.node.js',
    );
    const { AskLastNameNode } = load(
      'conversation/nodes/estimate/ask-last-name.node.js',
    );
    const { ConfirmPhoneNode } = load(
      'conversation/nodes/estimate/confirm-phone.node.js',
    );
    const { PromptAddressNode } = load(
      'conversation/nodes/estimate/prompt-address.node.js',
    );
    const { ResolveAddressNode } = load(
      'conversation/nodes/estimate/resolve-address.node.js',
    );
    const { ConfirmAddressMatchNode } = load(
      'conversation/nodes/estimate/confirm-address-match.node.js',
    );
    const { RejectAddressMatchNode } = load(
      'conversation/nodes/estimate/reject-address-match.node.js',
    );
    const { AskAppointmentAvailabilityNode } = load(
      'conversation/nodes/estimate/ask-appointment-availability.node.js',
    );
    const { DeclineAppointmentNode } = load(
      'conversation/nodes/estimate/decline-appointment.node.js',
    );
    const { CheckAvailabilityNode } = load(
      'conversation/nodes/estimate/check-availability.node.js',
    );
    const { RejectAppointmentSlotNode } = load(
      'conversation/nodes/estimate/reject-appointment-slot.node.js',
    );
    const { BookAppointmentNode } = load(
      'conversation/nodes/estimate/book-appointment.node.js',
    );
    const { ConfirmEmailNode } = load(
      'conversation/nodes/estimate/confirm-email.node.js',
    );
    const { OfferInstantEstimateNode } = load(
      'conversation/nodes/estimate/offer-instant-estimate.node.js',
    );
    const { AskTimelineNode } = load(
      'conversation/nodes/estimate/ask-timeline.node.js',
    );
    const { AskSlopeNode } = load(
      'conversation/nodes/estimate/ask-slope.node.js',
    );
    const { RejectSlopeNode } = load(
      'conversation/nodes/estimate/reject-slope.node.js',
    );
    const { DeliverEstimateNode } = load(
      'conversation/nodes/estimate/deliver-estimate.node.js',
    );
    const { GoodbyeNode } = load('conversation/nodes/goodbye.node.js');

    const brain = new MockBrainAdapter();
    brain.loadProfile(
      'roofr-estimate',
      join(root, 'config/poc/roofr-estimate.brain.yml'),
    );
    brain.setActiveProfile('roofr-estimate');

    const flow = new FlowLoader();
    flow.loadFromFile(join(root, 'config/flow.yaml'));

    const nodes = new Map([
      ['AcknowledgeNode', new AcknowledgeNode()],
      ['RoofEstimateIntentNode', new RoofEstimateIntentNode()],
      ['AskLastNameNode', new AskLastNameNode()],
      ['ConfirmPhoneNode', new ConfirmPhoneNode()],
      ['PromptAddressNode', new PromptAddressNode()],
      ['ResolveAddressNode', new ResolveAddressNode()],
      ['ConfirmAddressMatchNode', new ConfirmAddressMatchNode()],
      ['RejectAddressMatchNode', new RejectAddressMatchNode()],
      ['AskAppointmentAvailabilityNode', new AskAppointmentAvailabilityNode()],
      ['DeclineAppointmentNode', new DeclineAppointmentNode()],
      ['CheckAvailabilityNode', new CheckAvailabilityNode()],
      ['RejectAppointmentSlotNode', new RejectAppointmentSlotNode()],
      ['BookAppointmentNode', new BookAppointmentNode()],
      ['ConfirmEmailNode', new ConfirmEmailNode()],
      ['OfferInstantEstimateNode', new OfferInstantEstimateNode()],
      ['AskTimelineNode', new AskTimelineNode()],
      ['AskSlopeNode', new AskSlopeNode()],
      ['RejectSlopeNode', new RejectSlopeNode()],
      ['DeliverEstimateNode', new DeliverEstimateNode()],
      ['GoodbyeNode', new GoodbyeNode()],
    ]);

    const supervisor = new Supervisor(brain, flow, nodes, {
      log: mock.fn(),
      persist: mock.fn(async () => undefined),
    });

    const runtime = new SupervisedConversation({
      conversationId: 'est-conv',
      providerCallId: 'est-call',
      flowId: 'roofr-poc',
      brainProfileId: 'roofr-estimate',
      startNodeId: 'acknowledge',
      variables: { companyName: 'Roofr' },
    });

    async function turn(userText) {
      const chunks = [];
      const compiler = new VapiSseCompiler({
        id: `chatcmpl-${runtime.turn.turnNumber}`,
      });
      const writer = {
        write: (c) => chunks.push(c),
        end: () => undefined,
      };
      const result = await supervisor.handleTurn({
        runtime,
        userText,
        onSay: async (text) => compiler.writeAssistantText(writer, text),
      });
      await compiler.streamTerminalActions(writer, result.actions);
      const events = [];
      for (const part of chunks.join('').split('\n\n')) {
        const line = part.trim();
        if (!line.startsWith('data: ')) continue;
        const data = line.slice(6);
        if (data === '[DONE]') continue;
        events.push(JSON.parse(data));
      }
      const texts = events
        .map((e) => e.choices?.[0]?.delta?.content)
        .filter((c) => typeof c === 'string' && c.length);
      const tools = events.flatMap(
        (e) =>
          (e.choices?.[0]?.delta?.tool_calls ?? []).map(
            (t) => t.function?.name,
          ),
      );
      return { result, texts, tools };
    }

    // Opening turn: flow.start Acknowledge runs without Brain (Vapi speaks first).
    let t = await turn('');
    assert.equal(runtime.openingCompleted, true);
    assert.ok(t.texts.some((x) => /thanks for calling Roofr/i.test(x)));
    assert.ok(t.texts.some((x) => /how can I help/i.test(x)));
    assert.equal(runtime.memory.introSpoken, true);

    t = await turn('I need my roof estimate');
    assert.ok(t.texts.some((x) => x.includes('I can help you with that')));
    assert.ok(t.texts.some((x) => x.includes('first name')));

    t = await turn('Peter');
    assert.equal(runtime.memory.firstName, 'Peter');
    assert.ok(t.texts.some((x) => /Thanks, Peter/i.test(x)));
    assert.ok(t.texts.some((x) => /last name/i.test(x)));

    t = await turn('Pyskunov');
    assert.equal(runtime.memory.lastName, 'Pyskunov');
    assert.ok(t.texts.some((x) => /phone number/i.test(x)));

    t = await turn('yes');
    assert.equal(runtime.memory.phoneConfirmed, true);
    assert.ok(t.texts.some((x) => /address/i.test(x)));

    t = await turn('123 main street toronto');
    assert.ok(runtime.memory.addressQuery);
    assert.ok(t.texts.some((x) => /several matches/i.test(x)));
    assert.ok(t.texts.some((x) => /123 Main Street/i.test(x)));

    t = await turn('first one');
    assert.match(String(runtime.memory.selectedAddress), /123 Main Street/i);
    assert.ok(t.texts.some((x) => /appointment/i.test(x)));

    t = await turn('yes');
    assert.equal(runtime.memory.wantsAppointment, true);
    assert.ok(t.texts.some((x) => /what day or time/i.test(x)));

    t = await turn('tomorrow');
    assert.ok(t.texts.some((x) => /checking availability/i.test(x)));
    assert.ok(t.texts.some((x) => /9am/i.test(x)));
    assert.ok(t.texts.some((x) => /Which one is correct/i.test(x)));
    assert.deepEqual(runtime.memory.availableSlots, ['9am', '10am', '11am']);

    t = await turn('10am');
    assert.equal(runtime.memory.selectedSlot, '10am');
    assert.ok(t.texts.some((x) => /booked/i.test(x)));
    assert.ok(t.texts.some((x) => /email/i.test(x)));

    t = await turn('m a r k at r o o f r dot com');
    assert.equal(runtime.memory.email, 'mark@roofr.com');
    assert.ok(t.texts.some((x) => /mark@roofr\.com/i.test(x)));

    t = await turn('yes');
    assert.ok(t.texts.some((x) => /instant estimate/i.test(x)));

    t = await turn('yes');
    assert.ok(t.texts.some((x) => /timeline/i.test(x)));

    t = await turn('K.');
    assert.ok(t.texts.some((x) => /timeline/i.test(x)));
    assert.equal(runtime.memory.projectTimeline, undefined);

    t = await turn('asap');
    assert.equal(runtime.memory.projectTimeline, 'asap');
    assert.ok(t.texts.some((x) => /steep|moderate|rocky/i.test(x)));

    t = await turn('K.');
    assert.ok(t.texts.some((x) => /steep|moderate|rocky/i.test(x)));

    t = await turn('moderate');
    assert.ok(t.texts.some((x) => /between 10 and 15/i.test(x)));
    assert.ok(t.texts.some((x) => /other questions/i.test(x)));

    t = await turn('no');
    assert.ok(t.texts.some((x) => /goodbye/i.test(x)));
    assert.ok(t.tools.includes('end_call_tool'));
  });
});
