import { Injectable } from '@nestjs/common';
import {
  RA9_INTENTIONS,
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { pickAddressMatch } from '../../lib/estimate-parse';
import {
  clearListedChoice,
  openListedChoice,
} from '../../lib/listed-choice-listen';

/** Confirm which resolved address, then ask if they want an appointment. */
@Injectable()
export class ConfirmAddressMatchNode extends Ra9Node<RoofrConversationSchema> {
  async before(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<boolean> {
    const matches = ctx.memory.addressMatches ?? [];
    return Boolean(pickAddressMatch(ctx.userText, matches));
  }

  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isAcceptedAppointment', boost: 20 },
        { name: 'isDeclinedAppointment', boost: 20 },
        { name: RA9_INTENTIONS.isPositive, boost: 18 },
        { name: RA9_INTENTIONS.isNegative, boost: 18 },
        ...portalBoosts(),
      ],
      hints: [
        'Yes / sure / okay → isAcceptedAppointment (or ra9.isPositive).',
        'No / not now → isDeclinedAppointment (or ra9.isNegative).',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const matches = ctx.memory.addressMatches ?? [];
    const picked = pickAddressMatch(ctx.userText, matches);
    if (!picked) {
      const labels =
        ctx.memory.listedChoice?.labels ?? matches.map((m) => m.label);
      const choice = openListedChoice(ctx, {
        intro: 'I have several matches:',
        labels,
        pickIntention: 'isConfirmedAddressMatch',
        rejectIntention: 'isRejectedAddressMatch',
      });
      return ctx.output.sayAndListen(choice.text, choice.listen);
    }
    ctx.memory.selectedAddress = picked.label;
    ctx.memory.selectedAddressId = picked.id;
    clearListedChoice(ctx);

    await ctx.output.say('Great — got it.');
    return ctx.output.sayAndListen(
      'Would you like to book an appointment for a site visit?',
    );
  }
}
