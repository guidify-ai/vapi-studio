import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  RA9_INTENTIONS,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

@Injectable()
export class TransferToHumanNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation | null> {
    const attempts = ctx.runtime.portalState.transferToHuman.reengagementAttempts;
    if (attempts >= 1) {
      return null;
    }
    return {
      intentions: [
        { name: RA9_INTENTIONS.isTransferToHuman, boost: 30 },
        { name: 'isContinue', boost: 10 },
        { name: RA9_INTENTIONS.isGoodbye, boost: 5 },
      ],
      hints: [
        'User asked for a human — if they insist again, transfer.',
        'If they say okay/continue/fine, stay with the bot.',
        'ASR: "human"/"agent"/"representative"/"person"/"real someone".',
      ],
      note: 'Transfer re-engage listen',
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const portal = ctx.runtime.portalState.transferToHuman;
    if (portal.reengagementAttempts < 1) {
      portal.reengagementAttempts += 1;
      await ctx.events.persist(ctx.runtime.conversationId, 'TRANSFER_REENGAGE', {
        runtimeInstanceId: ctx.runtime.runtimeInstanceId,
        reengagementAttempts: portal.reengagementAttempts,
        originNodeId: ctx.runtime.portalState.originNodeId,
        note: 'in-memory portal state only; origin preserved',
      });
      return ctx.output.sayAndListen(
        'I understand you want to speak to a human, but I can resolve it for you.',
      );
    }

    await ctx.events.persist(ctx.runtime.conversationId, 'TRANSFER_EXECUTE', {
      runtimeInstanceId: ctx.runtime.runtimeInstanceId,
      reengagementAttempts: portal.reengagementAttempts,
      originNodeId: ctx.runtime.portalState.originNodeId,
    });
    await ctx.output.say('Connecting you to a human now.');
    return ctx.output.transferToHuman(process.env.VAPI_TRANSFER_DESTINATION);
  }
}
