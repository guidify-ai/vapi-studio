import { Injectable } from '@nestjs/common';
import {
  ConversationBootstrapService,
  EventService,
} from '@guidify-ai/ra9';
import type {
  VapiStrategy,
  VapiMessageType,
  VapiWebhookCommand,
  VapiWebhookResponse,
} from '../vapi.types';

@Injectable()
export class StatusUpdateStrategy implements VapiStrategy {
  constructor(
    private readonly bootstrap: ConversationBootstrapService,
    private readonly events: EventService,
  ) {}

  supports(type: VapiMessageType): boolean {
    return type === 'status-update';
  }

  async handle(command: VapiWebhookCommand): Promise<VapiWebhookResponse> {
    this.events.log('info', 'STATUS_UPDATE', {
      providerCallId: command.callId,
      status: command.status,
    });

    if (command.status === 'in-progress' || command.status === 'ringing') {
      const brainProfileId = process.env.POC_BRAIN_PROFILE || 'roofr-estimate';
      await this.bootstrap.bootstrap({
        providerCallId: command.callId,
        brainProfileId,
        metadata: {
          messageType: command.type,
          status: command.status,
          brainProfileId,
          ...(command.callerPhoneNumber
            ? { callerPhoneNumber: command.callerPhoneNumber }
            : {}),
        },
      });
    }

    if (command.status === 'ended') {
      await this.bootstrap.finalizeEnded(command.callId);
    }

    return { body: { ok: true } };
  }
}
