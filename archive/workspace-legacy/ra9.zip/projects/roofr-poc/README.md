# Roofr PoC

Private NestJS application on `@guidify-ai/ra9`. Proves that RA9 can run a **live Vapi inbound call** as a Custom LLM, with Roofr-shaped intake — not a production Roofr bot.

Repo: [pyskunov/rA9-project-roofr-poc](https://github.com/pyskunov/rA9-project-roofr-poc). Clone it to `projects/roofr-poc` inside [rA9-workspace](https://github.com/pyskunov/rA9-workspace). How to add other apps: [`../README.md`](../README.md).

## Northern stars

1. **RA9 + Vapi is real.** One inbound call creates one durable Conversation in Postgres and one in-memory supervised runtime reused for every Custom LLM turn until `status-update: ended`.
2. **Estimate intake, not a mega-prompt.** The bot should take a roof-estimate ask through identity (name, phone), a **CA/US address** (number, street, city, province/state — uninterruptible listen, queue ASR until 3s silence, re-ask if it does not look like an address), then **either** an appointment **or** an instant-estimate path (timeline + slope), then email and a clean close.
3. **Humans and safety stay reachable.** Transfer-to-human, pause, mad, unknown-transition, and goodbye remain available as portals / package intentions for the whole call. Transfer re-engages once in memory, then actually transfers.
4. **Framework stays generic.** Roofr copy, Nodes, mock sequence, and integrations live only in this app. RA9 must not learn Roofr.
5. **ChatGPT Brain on the live path — and the call must stay snappy.** Adapter + cheap model are set in `src/brain/brain.config.ts` (`adapter: 'ra9-chatgpt'`, `model: 'gpt-4.1-mini'`, scan threshold `0.4`). Requires `OPENAI_API_KEY`. No pre-scan listen-hold. Target: next bot question in **under 1.5s** after the Custom LLM request. Flip `adapter` to `'mock'` only to replay the YAML sequence. **Shit in, shit out:** Vapi stale repeats and weird callers are not in scope to fully handle.

## Triggers — update this README when any of these change

- The PoC’s purpose (Vapi proof vs production Roofr vs a different customer).
- The intake outcomes (appointment vs instant estimate vs something else becomes the star).
- Portal policy (e.g. transfer immediately, drop pause, add a new always-on portal).
- Default Brain / enabling ChatGPT / a Roofr-hosted Brain as the default (`src/brain/brain.config.ts`).
- Channel (anything other than Vapi Custom LLM + webhooks).
- Success criteria for a live call (what operators must hear or see in logs), including **live-call speed**.

Conversation paths, Node classes, and extract fields belong in `config/` and `src/conversation/`, not here.

## Run

Docker + Compose. Operator owns ngrok, Vapi dashboard URLs, and secrets.

```bash
cp .env.example .env
# PUBLIC_BASE_URL = ngrok HTTPS origin
docker compose up -d --build app
curl -s http://localhost:9999/health
```

- App: `localhost:9999`
- Postgres: `localhost:15432`
- Vapi webhook: `POST /vapi/webhook`
- Custom LLM: `POST /vapi/chat/completions`
- Daily call logs: this project's `logs/dailyYYYYMMDD.log` (`LOG_DIR=logs`, keep `LOG_DAYS` days, default 14). Console still prints. The folder is part of the app; the writer is RA9.

`yarn start` (see `scripts/start.sh`) brings Compose up and ngrok if you use that operator path.
