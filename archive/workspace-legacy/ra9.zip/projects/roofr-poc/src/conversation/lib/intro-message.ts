/** Shared Roofr intro / Vapi firstMessage text. */
export function introFirstMessage(): string {
  const company = process.env.POC_COMPANY_NAME?.trim() || 'Roofr';
  return `Hi, thanks for calling ${company}. This call is being recorded and by continuing you consent to the processing of your information. How can I help you today?`;
}
