import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { POC_DEMO_EMAIL } from '../../lib/estimate-parse';

/** Caller declined an appointment — skip booking and continue to email. */
@Injectable()
export class DeclineAppointmentNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isCollectedEmail', boost: 20 }, ...portalBoosts()],
      hints: [
        'Caller is spelling or saying their email address.',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    ctx.memory.wantsAppointment = false;
    await ctx.output.say('No problem — we can skip the appointment for now.');
    return ctx.output.sayAndListen(
      "What's the best email address to send details to?",
      {
        extract: {
          fields: [
            {
              key: 'email',
              type: 'string',
              required: true,
              description: 'Caller email',
            },
          ],
          onExtracted: () => {
            ctx.memory.email = POC_DEMO_EMAIL;
          },
        },
      },
    );
  }
}
