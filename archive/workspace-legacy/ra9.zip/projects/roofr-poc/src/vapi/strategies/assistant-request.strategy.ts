import { Injectable } from '@nestjs/common';
import {
  ConversationBootstrapService,
  DEFAULT_LISTEN_TIMEOUT_SECONDS,
  EventService,
  listenTimeoutToVapiStartSpeakingPlan,
} from '@guidify-ai/ra9';
import type {
  VapiStrategy,
  VapiMessageType,
  VapiWebhookCommand,
  VapiWebhookResponse,
} from '../vapi.types';

@Injectable()
export class AssistantRequestStrategy implements VapiStrategy {
  constructor(
    private readonly bootstrap: ConversationBootstrapService,
    private readonly events: EventService,
  ) {}

  supports(type: VapiMessageType): boolean {
    return type === 'assistant-request';
  }

  async handle(command: VapiWebhookCommand): Promise<VapiWebhookResponse> {
    const fromPayload =
      typeof command.raw.brainProfile === 'string'
        ? command.raw.brainProfile
        : undefined;
    const brainProfileId =
      fromPayload || process.env.POC_BRAIN_PROFILE || 'roofr-estimate';
    const runtime = await this.bootstrap.bootstrap({
      providerCallId: command.callId,
      brainProfileId,
      metadata: {
        messageType: command.type,
        brainProfileId,
        ...(command.callerPhoneNumber
          ? { callerPhoneNumber: command.callerPhoneNumber }
          : {}),
      },
    });

    this.events.log('info', 'ASSISTANT_REQUEST', {
      providerCallId: command.callId,
      conversationId: runtime.conversationId,
      runtimeInstanceId: runtime.runtimeInstanceId,
      brainProfileId,
    });

    const publicBase = (
      process.env.PUBLIC_BASE_URL ?? 'http://localhost:9999'
    ).replace(/\/$/, '');

    // Custom LLM owns the greeting (isAcknowledge). Avoid a second intro via firstMessage.
    return {
      body: {
        assistant: {
          name: 'RA9 Roofr PoC',
          model: {
            provider: 'custom-llm',
            url: `${publicBase}/vapi/chat/completions`,
            model: 'ra9-poc',
          },
          startSpeakingPlan: listenTimeoutToVapiStartSpeakingPlan(
            DEFAULT_LISTEN_TIMEOUT_SECONDS,
          ),
        },
      },
    };
  }
}
