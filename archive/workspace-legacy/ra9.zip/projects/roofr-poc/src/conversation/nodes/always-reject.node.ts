import { Injectable } from '@nestjs/common';
import { Ra9Node, type NodeContext, type NodeResult } from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

/** Demonstrates before() rejecting a candidate so Supervisor tries the next Node. */
@Injectable()
export class AlwaysRejectNode extends Ra9Node<RoofrConversationSchema> {
  async before(_ctx: NodeContext<RoofrConversationSchema>): Promise<boolean> {
    return false;
  }

  async run(_ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    throw new Error('AlwaysRejectNode must never run');
  }
}
