import assert from 'node:assert/strict';
import { describe, it, beforeEach, afterEach } from 'node:test';
import {
  VapiSseCompiler,
  extractNewestUserText,
  extractVapiCallId,
  resolveEndCallToolName,
} from '../dist/adapters/vapi/vapi-sse.compiler.js';

function collect(run) {
  const chunks = [];
  const writer = {
    write: (c) => chunks.push(c),
    end: () => chunks.push('__END__'),
  };
  run(writer);
  return chunks.join('');
}

function parseSse(raw) {
  const events = [];
  for (const part of raw.split('\n\n')) {
    const line = part.trim();
    if (!line.startsWith('data: ')) continue;
    const data = line.slice(6);
    if (data === '[DONE]') {
      events.push({ done: true });
      continue;
    }
    events.push(JSON.parse(data));
  }
  return events;
}

describe('VapiSseCompiler OpenAI-compatible SSE', () => {
  let prevEndCallName;

  beforeEach(() => {
    prevEndCallName = process.env.VAPI_END_CALL_TOOL_NAME;
    process.env.VAPI_END_CALL_TOOL_NAME = 'end_call_tool';
  });

  afterEach(() => {
    if (prevEndCallName === undefined) {
      delete process.env.VAPI_END_CALL_TOOL_NAME;
    } else {
      process.env.VAPI_END_CALL_TOOL_NAME = prevEndCallName;
    }
  });

  it('emits chat.completion.chunk assistant content frames', () => {
    const compiler = new VapiSseCompiler({ id: 'chatcmpl-test', model: 'ra9-poc' });
    const raw = collect((w) => {
      compiler.writeAssistantText(w, 'Hello there');
      compiler.finish(w);
    });
    const events = parseSse(raw);
    assert.equal(events[0].object, 'chat.completion.chunk');
    assert.equal(events[0].model, 'ra9-poc');
    assert.equal(events[0].choices[0].delta.role, 'assistant');
    assert.equal(events[0].choices[0].delta.content, 'Hello there');
    assert.equal(events[0].choices[0].finish_reason, null);
    assert.equal(events.at(-2).choices[0].finish_reason, 'stop');
    assert.equal(events.at(-1).done, true);
    assert.match(raw, /__END__/);
  });

  it('emits configured end_call_tool and does not follow with stop', async () => {
    const compiler = new VapiSseCompiler({
      id: 'chatcmpl-end',
      tools: [
        {
          type: 'function',
          function: { name: 'end_call_tool' },
        },
      ],
    });
    const chunks = [];
    const writer = {
      write: (c) => chunks.push(c),
      end: () => undefined,
    };
    const { emittedTools } = await compiler.streamTerminalActions(writer, [
      { kind: 'endCall', text: 'bye' },
    ]);
    assert.deepEqual(emittedTools, ['end_call_tool']);
    const events = parseSse(chunks.join(''));
    const tool = events.find((e) => e.choices?.[0]?.delta?.tool_calls?.[0]?.function?.name);
    assert.ok(tool);
    assert.equal(
      tool.choices[0].delta.tool_calls[0].function.name,
      'end_call_tool',
    );
    const finish = events.find((e) => e.choices?.[0]?.finish_reason === 'tool_calls');
    assert.ok(finish);
    assert.equal(
      events.some((e) => e.choices?.[0]?.finish_reason === 'stop'),
      false,
    );
    assert.equal(events.at(-1).done, true);
  });

  it('emits transferCall tool with destination JSON args', async () => {
    const compiler = new VapiSseCompiler({ id: 'chatcmpl-xfer' });
    const chunks = [];
    const writer = {
      write: (c) => chunks.push(c),
      end: () => undefined,
    };
    await compiler.streamTerminalActions(writer, [
      { kind: 'transferToHuman', destination: '+15551234567' },
    ]);
    const events = parseSse(chunks.join(''));
    const named = events.find(
      (e) => e.choices?.[0]?.delta?.tool_calls?.[0]?.function?.name === 'transferCall',
    );
    assert.ok(named);
    const withArgs = events.find((e) => {
      const args = e.choices?.[0]?.delta?.tool_calls?.[0]?.function?.arguments;
      return typeof args === 'string' && args.includes('destination');
    });
    assert.ok(withArgs);
    assert.deepEqual(
      JSON.parse(withArgs.choices[0].delta.tool_calls[0].function.arguments),
      { destination: '+15551234567' },
    );
  });

  it('resolves end call tool from advertised tools list', () => {
    assert.equal(
      resolveEndCallToolName([
        { type: 'function', function: { name: 'end_call_tool' } },
      ]),
      'end_call_tool',
    );
  });
});

describe('Vapi request helpers', () => {
  it('extracts newest user text from OpenAI messages', () => {
    assert.equal(
      extractNewestUserText({
        messages: [
          { role: 'user', content: 'first' },
          { role: 'assistant', content: 'ok' },
          { role: 'user', content: 'second' },
        ],
      }),
      'second',
    );
  });

  it('extracts Vapi call id from common body shapes', () => {
    assert.equal(extractVapiCallId({ call: { id: 'abc' } }), 'abc');
    assert.equal(extractVapiCallId({ callId: 'xyz' }), 'xyz');
    assert.equal(extractVapiCallId({ metadata: { call_id: 'm1' } }), 'm1');
    assert.equal(extractVapiCallId({}), null);
  });
});
