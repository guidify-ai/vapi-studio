import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import {
  clearListedChoice,
  listedChoiceIsReject,
} from '../../lib/listed-choice-listen';

/** None of the listed appointment slots — ask for another day/time. */
@Injectable()
export class RejectAppointmentSlotNode extends Ra9Node<RoofrConversationSchema> {
  async before(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<boolean> {
    return listedChoiceIsReject(
      ctx.userText,
      ctx.memory as Record<string, unknown>,
    );
  }

  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isRequestedAppointment', boost: 20 },
        ...portalBoosts(),
      ],
      hints: [
        'Caller says when they want an appointment (e.g. tomorrow, Friday morning).',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    ctx.memory.availableSlots = undefined;
    ctx.memory.selectedSlot = undefined;
    clearListedChoice(ctx);
    await ctx.output.say('Okay — none of those.');
    return ctx.output.sayAndListen(
      'What day or time works best for you?',
    );
  }
}
