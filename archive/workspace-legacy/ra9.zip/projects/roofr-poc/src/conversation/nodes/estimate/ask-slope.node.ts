import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { looksLikeProjectTimeline } from '../../lib/estimate-parse';
import {
  listedChoiceListen,
  openListedChoice,
  SLOPE_CHOICE_LABELS,
} from '../../lib/listed-choice-listen';

function slopeChoice(ctx: NodeContext<RoofrConversationSchema>) {
  return openListedChoice(ctx, {
    intro: 'I have several options:',
    labels: [...SLOPE_CHOICE_LABELS],
    pickIntention: 'isCollectedSlope',
    rejectIntention: 'isRejectedSlope',
  });
}

/** Instant estimate Q2 — roof slope as a numbered list. */
@Injectable()
export class AskSlopeNode extends Ra9Node<RoofrConversationSchema> {
  listenTimeoutSeconds = 3.5;
  async listen(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return listedChoiceListen(ctx.memory.listedChoice);
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const spoken = ctx.userText.trim();
    if (!looksLikeProjectTimeline(ctx.memory.projectTimeline ?? '')) {
      ctx.memory.projectTimeline = undefined;
    }
    const timelineOk =
      looksLikeProjectTimeline(spoken) ||
      Boolean(ctx.memory.projectTimeline);

    if (!timelineOk) {
      ctx.runtime.brainSequenceIndex = Math.max(
        0,
        ctx.runtime.brainSequenceIndex - 1,
      );
      return ctx.output.sayAndListen("What's the timeline for your project?", {
        timeoutSeconds: this.listenTimeoutSeconds,
        intentions: [
          { name: 'isCollectedTimeline', boost: 20 },
          ...portalBoosts(),
        ],
        hints: [
          'Caller answers timeline: ASAP, this month, next season, etc.',
        ],
      });
    }

    if (looksLikeProjectTimeline(spoken)) {
      ctx.memory.projectTimeline = spoken;
    }

    const choice = slopeChoice(ctx);
    return ctx.output.sayAndListen(choice.text, {
      ...choice.listen,
      timeoutSeconds: this.listenTimeoutSeconds,
    });
  }
}
