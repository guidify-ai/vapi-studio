import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import {
  listedChoiceIsReject,
  listedChoiceListen,
  openListedChoice,
  SLOPE_CHOICE_LABELS,
} from '../../lib/listed-choice-listen';

/** None of the listed slope options — ask the same list again. */
@Injectable()
export class RejectSlopeNode extends Ra9Node<RoofrConversationSchema> {
  listenTimeoutSeconds = 3.5;

  async before(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<boolean> {
    return listedChoiceIsReject(
      ctx.userText,
      ctx.memory as Record<string, unknown>,
    );
  }

  async listen(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return listedChoiceListen(ctx.memory.listedChoice);
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    ctx.memory.roofSlope = undefined;
    const choice = openListedChoice(ctx, {
      intro: 'I have several options:',
      labels: [...SLOPE_CHOICE_LABELS],
      pickIntention: 'isCollectedSlope',
      rejectIntention: 'isRejectedSlope',
    });
    await ctx.output.say('Okay — none of those.');
    return ctx.output.sayAndListen(choice.text, {
      ...choice.listen,
      timeoutSeconds: this.listenTimeoutSeconds,
    });
  }
}
