import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  RA9_INTENTIONS,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';
import { listedChoiceListen } from '../lib/listed-choice-listen';

/**
 * Portal for low-confidence / timed-out Brain scans (`ra9.isUnknownTransition`).
 * Re-ask. Do not infer transfer from a second LLM guess (shit in, shit out).
 * If a numbered list is on the line, pick-N / neither still cheap-matches.
 */
@Injectable()
export class UnknownTransitionNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    const choice = ctx.memory.listedChoice
      ? listedChoiceListen(ctx.memory.listedChoice)
      : null;
    return {
      intentions: [
        ...(choice?.intentions ?? []),
        { name: 'isContinue', boost: 10 },
        { name: RA9_INTENTIONS.isGoodbye, boost: 5 },
        { name: RA9_INTENTIONS.isTransferToHuman, boost: 5 },
        { name: RA9_INTENTIONS.isMad, boost: 10 },
      ],
      hints: [
        ...(choice?.hints ?? []),
        'Previous turn was unclear — user may clarify, repeat, or get frustrated.',
        'Prefer continue if they restate a normal request, unless they picked a listed option.',
      ],
      note: 'Unknown-transition recovery listen',
      resolveIntention: choice?.resolveIntention,
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const misses = (ctx.memory.unknownTransitionCount ?? 0) + 1;
    ctx.memory.unknownTransitionCount = misses;

    await ctx.events.persist(
      ctx.runtime.conversationId,
      'UNKNOWN_TRANSITION',
      {
        runtimeInstanceId: ctx.runtime.runtimeInstanceId,
        originNodeId: ctx.runtime.portalState.originNodeId,
        unknownTransitionCount: misses,
        userText: ctx.userText,
      },
    );

    if (misses >= 2) {
      return ctx.output.sayAndListen(
        "I'm still not sure I caught that. You can say it another way, or I can connect you to a person — which do you prefer?",
      );
    }

    return ctx.output.sayAndListen(
      "Sorry — I didn't quite catch that. Could you say it one more time?",
    );
  }
}
