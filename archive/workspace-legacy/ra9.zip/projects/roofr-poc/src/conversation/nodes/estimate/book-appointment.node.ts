import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { POC_DEMO_EMAIL } from '../../lib/estimate-parse';
import { bookAppointment } from '../../../integrations/mock-roofr.integration';
import { pickAppointmentSlot } from '../../lib/estimate-parse';
import {
  clearListedChoice,
  openListedChoice,
} from '../../lib/listed-choice-listen';

/** Book selected slot (emulate ~3s), confirm, ask email. */
@Injectable()
export class BookAppointmentNode extends Ra9Node<RoofrConversationSchema> {
  listenTimeoutSeconds = 3.5;
  async before(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<boolean> {
    const slots = ctx.memory.availableSlots ?? [];
    return Boolean(pickAppointmentSlot(ctx.userText, slots));
  }

  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isCollectedEmail', boost: 20 }, ...portalBoosts()],
      hints: [
        'Caller is spelling or saying their email address.',
        'ASR may arrive as "m a r k at r o o f r dot com".',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const slots = ctx.memory.availableSlots ?? ['9am', '10am', '11am'];
    const slot = pickAppointmentSlot(ctx.userText, slots);
    if (!slot) {
      const choice = openListedChoice(ctx, {
        intro: 'I have several openings:',
        labels: slots,
        pickIntention: 'isSelectedAppointmentSlot',
        rejectIntention: 'isRejectedAppointmentSlot',
      });
      return ctx.output.sayAndListen(choice.text, choice.listen);
    }
    ctx.memory.selectedSlot = slot;
    clearListedChoice(ctx);

    await ctx.output.say(
      `Got it — ${slot}. I'm booking that appointment now.`,
    );
    const booked = await bookAppointment({
      slot,
      address: ctx.memory.selectedAddress ?? '',
      firstName: ctx.memory.firstName,
      lastName: ctx.memory.lastName,
    });
    ctx.memory.appointmentConfirmationId = booked.confirmationId;

    await ctx.output.say(`You're booked for tomorrow at ${slot}.`);
    return ctx.output.sayAndListen(
      "What's the best email address to send the confirmation to?",
      {
        extract: {
          fields: [
            {
              key: 'email',
              type: 'string',
              required: true,
              description: 'Caller email',
            },
          ],
          onExtracted: (_data, _apply) => {
            // PoC: always confirm the demo email regardless of ASR.
            ctx.memory.email = POC_DEMO_EMAIL;
          },
        },
      },
    );
  }
}
