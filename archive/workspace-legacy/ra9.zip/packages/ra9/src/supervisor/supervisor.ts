import { Inject, Injectable, Optional } from '@nestjs/common';
import {
  BRAIN_SERVICE,
  type BrainService,
} from '../brain/brain.service';
import {
  resolveConfidenceThreshold,
  scoresToRankedCandidates,
  selectWalkableIntentions,
  type BrainIntentionOption,
} from '../brain/brain-ranking';
import { RA9_INTENTIONS } from '../intentions/standard-intentions';
import type { SupervisedConversation } from '../conversation/supervised-conversation';
import type { IntentionCandidate } from '../conversation/types';
import {
  appendChat,
  appendNodeVisit,
} from '../conversation/conversation-history';
import { DEFAULT_INTENTION_PRIORITY } from '../conversation/conversation-history';
import {
  mergeSayAndListenOptions,
  missingRequiredExtractKeys,
  tryResolveListenIntention,
  type ListenExpectation,
} from '../conversation/listen-expectation';
import { resolveListenTimeoutSeconds } from '../conversation/listen-timeout';
import { EventService } from '../events/event.service';
import { IntegrationClient } from '../integrations/integration-client';
import {
  RA9_BRAIN_CONFIG,
  type Ra9BrainConfig,
} from '../brain/brain-config';
import { snapshotUserMemory } from '../events/conversation-console';
import { FlowLoader, type FlowNodeDefinition } from '../flow/flow-loader';
import {
  RA9_NODE_REGISTRY,
  nodeContextFromRuntime,
  type NodeContext,
  type Ra9Node,
  type Ra9NodeRegistry,
} from '../node/ra9-node';
import type { CatchDirective } from '../node/catch-directive';
import {
  BufferedConversationOutput,
  type NodeResult,
  type OutputAction,
} from '../output/conversation-output';

const MAX_NODE_RESTARTS = 2;
const MAX_FORCE_INTENTION_HOPS = 3;

export interface TurnExecutionResult {
  runtime: SupervisedConversation;
  intentionNames: string[];
  selectedNodeId: string;
  selectedClass: string;
  result: NodeResult;
  actions: OutputAction[];
  portalOriginRestored?: string | null;
  extracted?: Record<string, unknown>;
}

@Injectable()
export class Supervisor {
  constructor(
    @Inject(BRAIN_SERVICE) private readonly brain: BrainService,
    private readonly flowLoader: FlowLoader,
    @Inject(RA9_NODE_REGISTRY) private readonly nodes: Ra9NodeRegistry,
    private readonly events: EventService,
    @Optional() private readonly integrations?: IntegrationClient,
    @Optional()
    @Inject(RA9_BRAIN_CONFIG)
    private readonly brainConfig?: Ra9BrainConfig,
  ) {}

  async handleTurn(input: {
    runtime: SupervisedConversation;
    userText: string;
    onSay?: (text: string) => Promise<void>;
  }): Promise<TurnExecutionResult> {
    const { runtime, userText, onSay } = input;
    runtime.turn.turnNumber += 1;
    runtime.turn.interrupted = false;
    appendChat(runtime.history, 'user', userText);

    const recordSay = async (text: string) => {
      appendChat(runtime.history, 'assistant', text);
      if (onSay) await onSay(text);
    };

    /**
     * Vapi Custom LLM (assistant speaks first / generated message mode):
     * the first request must run() flow.start — no Brain scan, no sequence advance.
     */
    if (!runtime.openingCompleted) {
      return this.executeOpeningTurn({ runtime, userText, onSay: recordSay });
    }

    const activeListen = runtime.listenExpectation;
    const candidates = this.buildBrainCandidates(activeListen);
    const confidenceThreshold = resolveConfidenceThreshold(
      this.brainConfig?.confidenceThreshold,
    );
    const resolvedName = await tryResolveListenIntention({
      listen: activeListen,
      userText,
      memory: runtime.memory as Record<string, unknown>,
    });
    const scan = resolvedName
      ? {
          intentions: scoresToRankedCandidates(
            [
              {
                name: resolvedName,
                confidence: 1,
                reason: 'listen_resolve',
              },
            ],
            candidates,
          ),
        }
      : await this.brain.scan({
          runtime,
          userText,
          listen: activeListen,
          candidates,
          confidenceThreshold,
          history: {
            chat: runtime.history.chat,
            nodes: runtime.history.nodes,
          },
        });
    if (resolvedName) {
      runtime.brainSequenceIndex = (runtime.brainSequenceIndex ?? 0) + 1;
      this.events.log('info', 'LISTEN_RESOLVED', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        turnNumber: runtime.turn.turnNumber,
        intention: resolvedName,
        userText,
      });
    }
    const intentions = scan.intentions;
    if (activeListen?.extract?.fields?.length) {
      const missingRequired = missingRequiredExtractKeys(
        activeListen.extract.fields,
        scan.extracted,
      );
      if (activeListen.extract.onExtracted) {
        await activeListen.extract.onExtracted(scan.extracted ?? {}, {
          memory: runtime.memory as Record<string, unknown>,
          variables: runtime.variables as Record<string, unknown>,
          userText,
        });
      }
      this.events.log('info', 'LISTEN_EXTRACTED', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        turnNumber: runtime.turn.turnNumber,
        extracted: scan.extracted,
        missingRequired,
        appliedViaCallback: Boolean(activeListen.extract.onExtracted),
        memory: snapshotUserMemory(
          runtime.memory as Record<string, unknown>,
        ),
      });
    }
    this.events.log('info', 'INTENTION_SCAN', {
      conversationId: runtime.conversationId,
      providerCallId: runtime.providerCallId,
      runtimeInstanceId: runtime.runtimeInstanceId,
      turnNumber: runtime.turn.turnNumber,
      intentions,
      extracted: scan.extracted,
      listen: activeListen,
      candidates,
      confidenceThreshold,
      activePortalId: runtime.portalState.activePortalId,
      originNodeId: runtime.portalState.originNodeId,
      normalFlowNodeId: runtime.normalFlowNodeId,
      memory: snapshotUserMemory(runtime.memory as Record<string, unknown>),
    });

    const ranked = selectWalkableIntentions(
      intentions,
      confidenceThreshold,
      RA9_INTENTIONS.isUnknownTransition,
    );
    const output = new BufferedConversationOutput(recordSay);

    const routed = await this.routeIntentions({
      runtime,
      userText,
      output,
      ranked,
      forceHop: 0,
    });

    return {
      runtime,
      intentionNames: ranked.map((i) => i.name),
      selectedNodeId: routed.selectedNodeId,
      selectedClass: routed.selectedClass,
      result: routed.result,
      actions: output.actions,
      portalOriginRestored: routed.portalOriginRestored,
      extracted: scan.extracted,
    };
  }

  /**
   * First Custom LLM turn: execute flow.start Node.run() so the assistant
   * speaks before any user utterance / Brain routing.
   */
  private async executeOpeningTurn(input: {
    runtime: SupervisedConversation;
    userText: string;
    onSay?: (text: string) => Promise<void>;
  }): Promise<TurnExecutionResult> {
    const { runtime, userText, onSay } = input;
    const flow = this.flowLoader.getFlow();
    const startId = flow.start;
    const candidate = flow.nodes[startId];
    if (!candidate) {
      throw new Error(`Flow start node "${startId}" missing`);
    }
    const node = this.nodes.get(candidate.class);
    if (!node) {
      throw new Error(`Start node class not registered: ${candidate.class}`);
    }

    const output = new BufferedConversationOutput(onSay);
    const ctx = nodeContextFromRuntime({
      runtime,
      userText,
      output,
      events: this.events,
      brain: this.brain,
      integrations: this.integrations,
      intention: candidate.intentions[0] ?? 'ra9.opening',
    });

    this.events.log('info', 'OPENING_TURN', {
      conversationId: runtime.conversationId,
      providerCallId: runtime.providerCallId,
      runtimeInstanceId: runtime.runtimeInstanceId,
      startNodeId: startId,
      class: candidate.class,
      userText,
      turnNumber: runtime.turn.turnNumber,
      memory: snapshotUserMemory(runtime.memory as Record<string, unknown>),
    });

    const can = await node.before(ctx);
    if (!can) {
      throw new Error(`Opening start node ${startId} rejected before()`);
    }

    if (candidate.portal) {
      this.enterPortal(runtime, candidate);
    } else {
      this.enterNormal(runtime, candidate);
    }

    const executed = await this.executeNodeWithCatch({
      runtime,
      userText,
      output,
      node,
      candidate,
      intentionName: candidate.intentions[0] ?? 'ra9.opening',
      ctx,
      restarts: 0,
      forceHop: 0,
    });

    if (executed.kind === 'forceIntention') {
      runtime.openingCompleted = true;
      this.events.log('info', 'OPENING_FORCE_INTENTION', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        intention: executed.intention,
      });
      const routed = await this.routeIntentions({
        runtime,
        userText,
        output,
        ranked: [
          {
            name: executed.intention,
            confidence: 1,
            priority: DEFAULT_INTENTION_PRIORITY,
            rank: 0,
          },
        ],
        forceHop: 1,
      });
      return {
        runtime,
        intentionNames: ['ra9.opening', executed.intention],
        selectedNodeId: routed.selectedNodeId,
        selectedClass: routed.selectedClass,
        result: routed.result,
        actions: output.actions,
        portalOriginRestored: routed.portalOriginRestored,
      };
    }

    runtime.openingCompleted = true;

    return {
      runtime,
      intentionNames: ['ra9.opening'],
      selectedNodeId: candidate.id,
      selectedClass: candidate.class,
      result: executed.result,
      actions: output.actions,
    };
  }

  private async routeIntentions(input: {
    runtime: SupervisedConversation;
    userText: string;
    output: BufferedConversationOutput;
    ranked: IntentionCandidate[];
    forceHop: number;
  }): Promise<{
    selectedNodeId: string;
    selectedClass: string;
    result: NodeResult;
    portalOriginRestored?: string | null;
  }> {
    const { runtime, userText, output, ranked, forceHop } = input;

    for (const scored of ranked) {
      const intentionName = scored.name;
      const nodeCandidates = this.flowLoader.nodesForIntention(intentionName);
      for (const candidate of nodeCandidates) {
        const node = this.nodes.get(candidate.class);
        if (!node) {
          this.events.log('warn', 'NODE_MISSING', {
            class: candidate.class,
            intention: intentionName,
          });
          continue;
        }

        const ctx = nodeContextFromRuntime({
          runtime,
          userText,
          output,
          events: this.events,
          brain: this.brain,
          integrations: this.integrations,
          intention: intentionName,
        });

        const can = await node.before(ctx);
        if (!can) {
          this.events.log('info', 'NODE_REJECT', {
            conversationId: runtime.conversationId,
            runtimeInstanceId: runtime.runtimeInstanceId,
            nodeId: candidate.id,
            class: candidate.class,
            intention: intentionName,
            confidence: scored.confidence,
            priority: scored.priority,
          });
          continue;
        }

        let portalOriginRestored: string | null | undefined;
        if (candidate.portal) {
          portalOriginRestored = this.enterPortal(runtime, candidate);
        } else {
          portalOriginRestored = this.enterNormal(runtime, candidate);
        }

        const executed = await this.executeNodeWithCatch({
          runtime,
          userText,
          output,
          node,
          candidate,
          intentionName,
          ctx,
          restarts: 0,
          forceHop,
        });

        if (executed.kind === 'forceIntention') {
          if (forceHop >= MAX_FORCE_INTENTION_HOPS) {
            throw new Error(
              `forceIntention hop limit (${MAX_FORCE_INTENTION_HOPS}) exceeded`,
            );
          }
          this.events.log('info', 'CATCH_FORCE_INTENTION', {
            conversationId: runtime.conversationId,
            runtimeInstanceId: runtime.runtimeInstanceId,
            fromNodeId: candidate.id,
            intention: executed.intention,
            forceHop: forceHop + 1,
          });
          return this.routeIntentions({
            runtime,
            userText,
            output,
            ranked: [
              {
                name: executed.intention,
                confidence: 1,
                priority: DEFAULT_INTENTION_PRIORITY,
                rank: 0,
              },
            ],
            forceHop: forceHop + 1,
          });
        }

        return {
          selectedNodeId: candidate.id,
          selectedClass: candidate.class,
          result: executed.result,
          portalOriginRestored,
        };
      }
    }

    throw new Error('Supervisor could not route turn to any eligible node');
  }

  private async executeNodeWithCatch(input: {
    runtime: SupervisedConversation;
    userText: string;
    output: BufferedConversationOutput;
    node: Ra9Node;
    candidate: FlowNodeDefinition;
    intentionName: string;
    ctx: NodeContext;
    restarts: number;
    forceHop: number;
  }): Promise<
    | { kind: 'done'; result: NodeResult }
    | { kind: 'forceIntention'; intention: string }
  > {
    const {
      runtime,
      output,
      node,
      candidate,
      intentionName,
      ctx,
      restarts,
    } = input;

    // Register listen BEFORE speech so mid-talk interrupts still bind here.
    const listenExpectation = await node.listen(ctx);
    runtime.listenExpectation = listenExpectation;
    this.stampListenTimeout(runtime, node);
    if (listenExpectation) {
      this.events.log('info', 'LISTEN_REGISTERED', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        nodeId: candidate.id,
        class: candidate.class,
        listen: runtime.listenExpectation,
        restart: restarts,
      });
    }

    this.events.log('info', 'NODE_ENTER', {
      conversationId: runtime.conversationId,
      runtimeInstanceId: runtime.runtimeInstanceId,
      nodeId: candidate.id,
      class: candidate.class,
      intention: intentionName,
      portal: Boolean(candidate.portal),
      originNodeId: runtime.portalState.originNodeId,
      normalFlowNodeId: runtime.normalFlowNodeId,
      activePortalId: runtime.portalState.activePortalId,
      restart: restarts,
      turnNumber: runtime.turn.turnNumber,
      memory: snapshotUserMemory(runtime.memory as Record<string, unknown>),
    });
    if (restarts === 0) {
      appendNodeVisit(runtime.history, {
        nodeId: candidate.id,
        intention: intentionName,
        turnNumber: runtime.turn.turnNumber,
        at: new Date().toISOString(),
      });
    }

    try {
      const result = await node.run(ctx);
      if (result.kind === 'sayAndListen') {
        runtime.listenExpectation = mergeSayAndListenOptions(
          runtime.listenExpectation,
          result.sayAndListen,
        );
        this.stampListenTimeout(
          runtime,
          node,
          result.sayAndListen?.timeoutSeconds,
        );
        if (result.sayAndListen?.extract?.fields?.length) {
          this.events.log('info', 'LISTEN_EXTRACT_REGISTERED', {
            conversationId: runtime.conversationId,
            runtimeInstanceId: runtime.runtimeInstanceId,
            nodeId: candidate.id,
            fields: result.sayAndListen.extract.fields,
            hasOnExtracted: Boolean(result.sayAndListen.extract.onExtracted),
          });
        }
      }
      await node.after(ctx, result);
      this.events.log('info', 'NODE_AFTER', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        nodeId: candidate.id,
        class: candidate.class,
        resultKind: result.kind,
        turnNumber: runtime.turn.turnNumber,
        memory: snapshotUserMemory(runtime.memory as Record<string, unknown>),
        actions: output.actions.map((a) => a.kind),
      });
      return { kind: 'done', result };
    } catch (error) {
      const directive: CatchDirective = await node.catch(ctx, error);
      this.events.log('warn', 'NODE_CATCH', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        nodeId: candidate.id,
        class: candidate.class,
        error:
          error instanceof Error
            ? { name: error.name, message: error.message }
            : { message: String(error) },
        directive,
        restart: restarts,
      });

      if (directive.kind === 'restartNode') {
        if (restarts >= MAX_NODE_RESTARTS) {
          throw new Error(
            `restartNode limit (${MAX_NODE_RESTARTS}) exceeded for ${candidate.id}`,
          );
        }
        // Drop partial speech from the failed attempt before retrying.
        output.actions.length = 0;
        return this.executeNodeWithCatch({
          ...input,
          restarts: restarts + 1,
        });
      }

      if (directive.kind === 'forceIntention') {
        output.actions.length = 0;
        return { kind: 'forceIntention', intention: directive.intention };
      }

      if (directive.kind === 'result') {
        await node.after(ctx, directive.result);
        return { kind: 'done', result: directive.result };
      }

      throw error;
    }
  }

  /**
   * Limited Brain candidate set for this listen:
   * - listen-prioritized next-node intentions (with boost + priority)
   * - all portal intentions
   * - ra9.isUnknownTransition (scan-failure global)
   * - if no listen yet: all normal-flow intentions + portals
   */
  private buildBrainCandidates(
    listen: ListenExpectation | null | undefined,
  ): BrainIntentionOption[] {
    const byName = new Map<string, BrainIntentionOption>();

    const upsert = (option: BrainIntentionOption) => {
      const existing = byName.get(option.name);
      if (!existing) {
        byName.set(option.name, {
          ...option,
          priority: option.priority ?? DEFAULT_INTENTION_PRIORITY,
        });
        return;
      }
      byName.set(option.name, {
        ...existing,
        boost: Math.max(existing.boost ?? 0, option.boost ?? 0),
        priority: Math.max(
          existing.priority ?? DEFAULT_INTENTION_PRIORITY,
          option.priority ?? DEFAULT_INTENTION_PRIORITY,
        ),
        source: existing.source === 'listen' ? 'listen' : option.source,
      });
    };

    for (const intent of listen?.intentions ?? []) {
      upsert({
        name: intent.name,
        boost: intent.boost,
        priority: intent.priority,
        source: 'listen',
      });
    }

    for (const name of this.flowLoader.portalIntentionNames()) {
      upsert({ name, source: 'portal' });
    }

    if (!listen?.intentions?.length) {
      for (const name of this.flowLoader.normalIntentionNames()) {
        upsert({ name, source: 'flow' });
      }
    }

    upsert({
      name: RA9_INTENTIONS.isUnknownTransition,
      boost: 0,
      priority: 0,
      source: 'runtime',
    });

    return [...byName.values()];
  }

  /**
   * Stamp the resolved listen window onto the active expectation.
   * sayAndListen timeout > listen() timeout > Node.listenTimeoutSeconds > default.
   */
  private stampListenTimeout(
    runtime: SupervisedConversation,
    node: Ra9Node,
    fromSayAndListen?: number,
  ): void {
    const timeoutSeconds = resolveListenTimeoutSeconds({
      fromSayAndListen,
      fromListen: runtime.listenExpectation?.timeoutSeconds,
      fromNode: node.listenTimeoutSeconds,
    });
    if (!runtime.listenExpectation) {
      runtime.listenExpectation = {
        intentions: [],
        timeoutSeconds,
        interruptible: node.interruptible,
      };
      return;
    }
    runtime.listenExpectation.timeoutSeconds = timeoutSeconds;
    if (runtime.listenExpectation.interruptible === undefined) {
      runtime.listenExpectation.interruptible = node.interruptible;
    }
  }

  private enterPortal(
    runtime: SupervisedConversation,
    candidate: FlowNodeDefinition,
  ): string | null | undefined {
    const switching =
      runtime.portalState.activePortalId &&
      runtime.portalState.activePortalId !== candidate.id;

    if (switching) {
      const restored = runtime.exitPortal();
      this.events.log('info', 'PORTAL_EXIT', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        restoredOriginNodeId: restored,
        reason: 'switch_portal',
      });
    }

    const alreadyInSame =
      runtime.portalState.activePortalId === candidate.id;

    runtime.enterPortal(candidate.id);

    this.events.log('info', alreadyInSame ? 'PORTAL_REENTER' : 'PORTAL_ENTER', {
      conversationId: runtime.conversationId,
      runtimeInstanceId: runtime.runtimeInstanceId,
      portalId: candidate.id,
      originNodeId: runtime.portalState.originNodeId,
    });

    return undefined;
  }

  private enterNormal(
    runtime: SupervisedConversation,
    candidate: FlowNodeDefinition,
  ): string | null | undefined {
    let restored: string | null | undefined;
    if (runtime.portalState.activePortalId) {
      restored = runtime.exitPortal();
      this.events.log('info', 'PORTAL_EXIT', {
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        restoredOriginNodeId: restored,
        nextNodeId: candidate.id,
        reason: 'normal_intention',
      });
    }
    runtime.enterNormalNode(candidate.id);
    return restored;
  }
}
