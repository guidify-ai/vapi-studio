# Roofr PoC — conversation flow

Live script (`config/flow.yaml`). Intention **names** on the arrows are what each Node listens for. With `adapter: 'ra9-chatgpt'`, ChatGPT **scores** those candidates each turn (it does not walk the mock YAML sequence). Mock Brain still uses `config/poc/roofr-estimate.brain.yml` if you flip the adapter back.

Each box is a **Node**. The label on the arrow is the **intention that enters** that Node. The Node then speaks and **listens for the next** intention (one-shot: enter on the previous answer, ask the next question).

Opening turn runs `acknowledge` with **no Brain scan**. Portals can interrupt from any listen.

```text
  CALL START (Vapi Custom LLM, assistant speaks first)
           |
           |  (no scan)
           v
  +------------------+
  |   acknowledge    |  BOT: Hi, thanks for calling Roofr. ... How can I help you today?
  +--------+---------+
           |
           |  USER: roof estimate
           |  isRequestedRoofEstimate
           v
  +------------------+
  |   roofEstimate   |  BOT: I can help you with that.
  |                  |       I need to collect some information from you first.
  |                  |       What's your first name?
  +--------+---------+
           |
           |  USER: (first name)     [stores extracted first name]
           |  isCollectedFirstName
           v
  +------------------+
  |   askLastName    |  BOT: Thanks, {firstName}. And your last name?
  +--------+---------+
           |
           |  USER: (last name)
           |  isCollectedLastName
           v
  +------------------+
  |   confirmPhone   |  BOT: Is the phone number you're calling from
  |                  |       the best number to reach you?
  +--------+---------+
           |
           |  USER: yes
           |  isConfirmedPhone
           v
  +------------------+
  |   promptAddress  |  BOT: Great. What's the address ...?
  |                  |       Number, street, city, province/state.
  |                  |       uninterruptible; queue ASR until 3s silence
  +--------+---------+
           |
           |  USER: (CA/US address)
           |  isCollectedAddress
           |  If it does not look like Number-Street-City-Province/State:
           |  BOT: Let me make sure I heard that address correctly.
           |  then Brain.clarify, then re-ask (once).
           v
  +------------------+
  |  resolveAddress  |  BOT: Thanks. Let me look that address up.
  |                  |       I have several matches: 1) ... 2) ... 3) ...
  |                  |       Which one is correct?
  +--------+---------+
           |
           |  USER: first / second / 1 / 2 / neither
           |  isConfirmedAddressMatch  |  isRejectedAddressMatch
           v                           v
  +------------------+        +------------------+
  | confirmAddress   |        | rejectAddress    |  BOT: Okay — none of those.
  |     Match        |        |     Match        |       What's the address ...?
  |  BOT: Great —    |        +--------+---------+
  |  got it.         |                 |
  |  Would you like  |                 |  (back to address collect)
  |  to book an      |
  |  appointment...  |
  +--------+---------+
           |
           +---------------------------+----------------------------+
           | yes                       | no
           | isAcceptedAppointment     | isDeclinedAppointment
           | ra9.isPositive            | ra9.isNegative
           v                           v
  +------------------+        +------------------+
  | askAppointment   |        | declineAppoint-  |  BOT: No problem — we can skip
  |   Availability   |        |      ment        |       the appointment for now.
  |                  |        |                  |       What's the best email address
  | BOT: Great —     |        |                  |       to send details to?
  | what day or time |        +--------+---------+
  | works best?      |                 |
  +--------+---------+                 |
           |                           |
           |  USER: tomorrow           |
           |  isRequestedAppointment   |
           v                           |
  +------------------+                 |
  | checkAvailability|  BOT: Okay — I'm checking availability...
  |                  |       I have several openings: 1) 9am, and 2) 10am, and 3) 11am.
  |                  |       Which one is correct? First, second, or neither?
  +--------+---------+                 |
           |
           |  USER: first / 10am / neither
           |  isSelectedAppointmentSlot  |  isRejectedAppointmentSlot
           v                             v
  +------------------+          +------------------+
  |  bookAppointment |          | rejectSlot       |  BOT: Okay — none of those.
  |  BOT: Got it —   |          |                  |       What day or time works best?
  |  10am. Booking.  |          +--------+---------+
  |  What's the best |                   |
  |  email...        |                   |  (back to day/time)
  +--------+---------+
           |
           |  USER: (email / spelled)
           |  isCollectedEmail
                         |
                         |  [PoC always confirms mark@roofr.com]
                         v
                +------------------+
                |   confirmEmail   |  BOT: I heard mark@roofr.com. Is that correct?
                +--------+---------+
                         |
                         |  USER: yes
                         |  isConfirmedEmail
                         v
                +------------------+
                | offerInstantEst. |  BOT: I can also give you an instant estimate
                |                  |       while we are on the call. Would you like
                |                  |       to do that?
                +--------+---------+
                         |
                         |  USER: yes     (mock sequence always continues here)
                         |  isAcceptedInstantEstimate
                         v
                +------------------+
                |    askTimeline   |  BOT: What's the timeline for your project?
                +--------+---------+
                         |
                         |  USER: asap / this month / as soon as possible
                         |  isCollectedTimeline
                         |  (filler like "K." re-asks timeline)
                         v
                +------------------+
                |     askSlope     |  BOT: I have several options: 1) steep, and
                |                  |       2) a moderate slope, and 3) rocky mountain.
                |                  |       Which one is correct? First, second, or neither?
                +--------+---------+
                         |
                         |  USER: first / moderate / neither
                         |  isCollectedSlope  |  isRejectedSlope
                         v
                +------------------+
                | deliverEstimate  |  BOT: Based on what you told me, your estimate
                |                  |       is between 10 and 15 thousand dollars.
                |                  |       Do you have any other questions?
                +--------+---------+
                         |
                         |  USER: no / goodbye
                         |  isAnsweredOtherQuestions  |  ra9.isGoodbye
                         v
                +------------------+
                |     goodbye      |  BOT: Thanks for calling, {firstName}. Goodbye.
                |    (terminal)    |       [endCall]
                +------------------+
                         |
                         v
                      CALL END
```

## Portals (any turn)

Always eligible. They do **not** consume the mock estimate sequence. Origin Node is restored when the caller continues.

```text
                    any listen
                         |
         +---------------+---------------+---------------+
         |               |               |               |
         | ra9.isPause   | ra9.isMad     | ra9.isUnknown | ra9.isTransferToHuman
         | pri 90        | pri 95        | Transition    | pri 100
         |               |               | pri 85        |
         v               v               v               v
      [pause]         [mad]      [unknownTransition]  [transferToHuman]
         |               |               |               |
         | "Sure, take   | de-escalate   | re-ask        | 1st: "I can resolve
         |  your time."  |               | (no transfer) |     it for you."
         |               |               |               | 2nd: transferCall
         |               |               |               |
         +-------+-------+-------+-------+---------------+
                 |
                 |  isContinue / resume
                 v
            origin Node
            (same question)
```

## Mock Brain sequence (`adapter: 'mock'` only)

Opening does not consume a slot. After that, one intention per Custom LLM turn. **Unused** while `adapter` is `ra9-chatgpt`.

```text
isRequestedRoofEstimate
  -> isCollectedFirstName
  -> isCollectedLastName
  -> isConfirmedPhone
  -> isCollectedAddress
  -> isConfirmedAddressMatch
  -> isAcceptedAppointment
  -> isRequestedAppointment
  -> isSelectedAppointmentSlot
  -> isCollectedEmail
  -> isConfirmedEmail
  -> isAcceptedInstantEstimate
  -> isCollectedTimeline
  -> isCollectedSlope
  -> isAnsweredOtherQuestions
```

A filler ASR crumb (`K.`, `ok`) that is not a real timeline/slope/day-time **rewinds** that slot and re-asks.

## How to read a box

```text
  +------------------+
  |   nodeId         |  BOT: what this Node speaks (asks the NEXT question)
  +--------+---------+
           |
           |  USER: typical answer
           |  intention that SELECTS the next Node
           v
```

Source of truth for paths: `config/flow.yaml`. Spoken copy lives on the Node classes under `src/conversation/nodes/`.
