import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import {
  confirmLooksLikeAddress,
  reaskAddress,
} from '../../lib/address-collect';
import {
  addressChoiceListen,
  openListedChoice,
} from '../../lib/listed-choice-listen';
import { resolveAddressFromText } from '../../../integrations/mock-roofr.integration';

/** Emulate Roofr address resolve and ask which match is correct. */
@Injectable()
export class ResolveAddressNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return addressChoiceListen();
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const spoken = ctx.userText.trim();
    const query = spoken || (ctx.memory.addressQuery ?? '').trim();
    const attempts = ctx.memory.addressCollectAttempts ?? 0;

    if (!query) {
      ctx.memory.addressQuery = undefined;
      ctx.memory.addressCollectAttempts = attempts + 1;
      return reaskAddress(ctx);
    }

    const check = await confirmLooksLikeAddress(ctx, query);
    if (!check.ok) {
      ctx.memory.addressCollectAttempts = attempts + 1;
      await ctx.events.persist(ctx.runtime.conversationId, 'ADDRESS_NOT_ADDRESS', {
        runtimeInstanceId: ctx.runtime.runtimeInstanceId,
        query,
        attempts: ctx.memory.addressCollectAttempts,
      });
      if (attempts < 1 || !/\d/.test(query)) {
        return reaskAddress(ctx);
      }
    }

    ctx.memory.addressQuery = check.normalized || query;

    await ctx.output.say('Thanks. Let me look that address up.');
    const matches = await resolveAddressFromText(ctx.memory.addressQuery);
    ctx.memory.addressMatches = matches;
    const choice = openListedChoice(ctx, {
      intro: 'I have several matches:',
      labels: matches.map((m) => m.label),
      pickIntention: 'isConfirmedAddressMatch',
      rejectIntention: 'isRejectedAddressMatch',
    });
    return ctx.output.sayAndListen(choice.text, choice.listen);
  }
}
