import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  RA9_INTENTIONS,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

@Injectable()
export class InterruptTestNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: RA9_INTENTIONS.isGoodbye, boost: 25 },
        { name: 'isContinue', boost: 5 },
      ],
      hints: [
        'User may interrupt mid-speech — treat interruption text as the answer.',
        'Anything like bye/thanks/done → goodbye/endCall.',
        'ASR may clip mid-word; prefer goodbye when uncertain near end of demo.',
      ],
      note: 'Interrupt window — listen registered before long speech',
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    await ctx.output.say(
      'I am going to keep talking for a while so that you can interrupt me. Feel free to cut me off whenever you want.',
    );
    await sleep(5000);
    await ctx.output.say(
      'I am still talking on purpose, so we can observe how Vapi reports the interruption.',
    );
    await sleep(5000);
    return ctx.output.sayAndListen(
      'Interrupt window finished. Say anything and I will wrap up.',
    );
  }
}
