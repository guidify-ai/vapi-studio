import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';

/** After email confirm — offer an instant estimate on the call. */
@Injectable()
export class OfferInstantEstimateNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isAcceptedInstantEstimate', boost: 20 },
        ...portalBoosts(),
      ],
      hints: ['Yes means they want the instant estimate on this call.'],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const text = ctx.userText.toLowerCase();
    ctx.memory.emailConfirmed = /\b(yes|yeah|yep|correct|sure|ok|okay)\b/.test(
      text,
    );
    return ctx.output.sayAndListen(
      'I can also give you an instant estimate while we are on the call. Would you like to do that?',
    );
  }
}
