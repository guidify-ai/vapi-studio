# Quickstart / Operator Runbook

## Prerequisites

- Docker + Docker Compose
- ngrok (or equivalent) on the operator machine
- Access to Roofr Vapi account (operator-owned)
- Optional: OpenAI key later; MVP uses mock Brain

Host Node/Yarn installs are **not** required.

## Workspace paths

```text
/Users/markpyskunov/work/guidify-ai/packages/ra9           # framework package
/Users/markpyskunov/work/guidify-ai/projects/roofr-poc     # RA9 Nest application skeleton
```

## Start stack

From `guidify-ai/projects/roofr-poc`:

```bash
cp .env.example .env
# set PUBLIC_BASE_URL to your ngrok HTTPS origin before live Vapi tests
docker compose up --build
curl -s http://localhost:9999/health
```

Expected services:

- `app` HTTP on `localhost:9999`
- `postgres` on private compose network

Health check:

```bash
curl -s http://localhost:9999/health
```

## Environment

Copy `.env.example` → `.env` (never commit secrets):

- `DATABASE_URL`
- `PUBLIC_BASE_URL` (ngrok HTTPS origin)
- `POC_BRAIN_PROFILE=state-machine` or `transfer-human`
- `VAPI_TRANSFER_DESTINATION` (phone/assistant target for Scenario 2)
- optional `VAPI_WEBHOOK_SECRET`
- optional `OPENAI_API_KEY` (unused by mock Brain)

## Tunnel

```bash
ngrok http 9999
```

Set Vapi phone number Server URL to:

`https://<ngrok>/vapi/webhook`

Ensure assistant Custom LLM URL is:

`https://<ngrok>/vapi/chat/completions`

Exact Vapi dashboard field names vary; capture screenshots/notes during first setup.

## Acceptance Scenario 1 (state machine)

1. Set `POC_BRAIN_PROFILE=state-machine`, restart app container.
2. Place inbound call.
3. Follow scripted turns (acknowledge → multi-say with pauses → interrupt → goodbye/end).
4. Verify logs for:
   - bootstrap Conversation + `runtimeInstanceId`
   - same `runtimeInstanceId` each Custom LLM turn
   - ranked intentions including `ra9.isGoodbye`
   - multiple `say` emissions
   - interrupt observation
   - `endCall` tool stream
   - `status-update ended` finalize + registry removal

## Acceptance Scenario 2 (transfer portal)

1. Set `POC_BRAIN_PROFILE=transfer-human`, configure transfer destination, restart.
2. Place inbound call.
3. First transfer intention → re-engagement speech, no transfer.
4. Second transfer intention → real `transferCall`.
5. End call; verify portal counter was in-memory and durable row ended cleanly.

## Build notes for agents

All `yarn install` / `yarn build` / tests for Node packages MUST run inside Docker, e.g.:

```bash
docker compose run --rm app yarn test
```

(Exact service name finalized during scaffold.)
