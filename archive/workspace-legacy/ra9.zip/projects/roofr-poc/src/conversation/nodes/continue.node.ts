import { Injectable } from '@nestjs/common';
import { Ra9Node, type NodeContext, type NodeResult } from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

/** Resumes normal conversation after leaving a portal (e.g. Pause). */
@Injectable()
export class ContinueNode extends Ra9Node<RoofrConversationSchema> {
  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    return ctx.output.sayAndListen('Okay, continuing.');
  }
}
