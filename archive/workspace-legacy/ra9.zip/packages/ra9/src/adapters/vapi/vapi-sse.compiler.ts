import type { OutputAction } from '../../output/conversation-output';

export interface VapiStreamWriter {
  write(chunk: string): void;
  end(): void;
}

export type VapiToolLike =
  | {
      type?: string;
      function?: { name?: string };
      name?: string;
    }
  | Record<string, unknown>;

function sseData(payload: unknown): string {
  return `data: ${JSON.stringify(payload)}\n\n`;
}

export function extractToolFunctionNames(tools: unknown): string[] {
  if (!Array.isArray(tools)) {
    return [];
  }
  const names: string[] = [];
  for (const tool of tools) {
    if (!tool || typeof tool !== 'object') {
      continue;
    }
    const t = tool as VapiToolLike;
    const fnObj =
      typeof t.function === 'object' && t.function
        ? (t.function as { name?: string })
        : null;
    const fnName =
      (fnObj && typeof fnObj.name === 'string' ? fnObj.name : null) ??
      (typeof t.name === 'string' ? t.name : null);
    if (fnName) {
      names.push(fnName);
    }
    // Built-in Vapi tool types often appear as type-only entries.
    if (typeof t.type === 'string' && ['endCall', 'transferCall'].includes(t.type)) {
      names.push(t.type);
    }
  }
  return [...new Set(names)];
}

export function resolveEndCallToolName(tools?: unknown): string {
  const advertised = extractToolFunctionNames(tools ?? []);
  const configured =
    process.env.VAPI_END_CALL_TOOL_NAME?.trim() || 'end_call_tool';

  if (advertised.includes(configured)) {
    return configured;
  }
  for (const candidate of ['end_call_tool', 'endCall', 'end_call']) {
    if (advertised.includes(candidate)) {
      return candidate;
    }
  }
  const fuzzy = advertised.find((n) => /end.*call/i.test(n));
  if (fuzzy) {
    return fuzzy;
  }
  // Force configured name even if Vapi omitted it from this request's tools list.
  return configured;
}

export function resolveTransferCallToolName(tools?: unknown): string {
  const advertised = extractToolFunctionNames(tools ?? []);
  const configured =
    process.env.VAPI_TRANSFER_CALL_TOOL_NAME?.trim() || 'transferCall';
  if (advertised.includes(configured)) {
    return configured;
  }
  if (advertised.includes('transferCall')) {
    return 'transferCall';
  }
  const fuzzy = advertised.find((n) => /transfer/i.test(n));
  return fuzzy ?? configured;
}

/**
 * Compiles RA9 output actions into OpenAI-compatible SSE for Vapi Custom LLM.
 */
export class VapiSseCompiler {
  private readonly model: string;
  private readonly id: string;
  private readonly tools: unknown;

  constructor(opts?: { model?: string; id?: string; tools?: unknown }) {
    this.model = opts?.model ?? 'ra9-poc';
    this.id = opts?.id ?? `chatcmpl-${Date.now()}`;
    this.tools = opts?.tools;
  }

  /** Replay prior assistant utterances onto this SSE (coalesced waiter). */
  replayAssistantSpeech(writer: VapiStreamWriter, texts: string[]): void {
    const spoken = texts.map((t) => t.trim()).filter(Boolean);
    if (spoken.length === 0) {
      this.writeAssistantText(writer, '');
      return;
    }
    for (const text of spoken) {
      this.writeAssistantText(writer, text);
    }
  }

  writeAssistantText(writer: VapiStreamWriter, text: string): void {
    writer.write(
      sseData({
        id: this.id,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: this.model,
        choices: [
          {
            index: 0,
            delta: { role: 'assistant', content: text },
            finish_reason: null,
          },
        ],
      }),
    );
  }

  writeToolCall(
    writer: VapiStreamWriter,
    name: string,
    args: Record<string, unknown>,
    index = 0,
  ): void {
    const callId = `call_${name}_${Date.now()}_${index}`;
    // OpenAI-style streaming: announce tool call, then finalize with tool_calls.
    writer.write(
      sseData({
        id: this.id,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: this.model,
        choices: [
          {
            index: 0,
            delta: {
              role: 'assistant',
              content: null,
              tool_calls: [
                {
                  index,
                  id: callId,
                  type: 'function',
                  function: {
                    name,
                    arguments: '',
                  },
                },
              ],
            },
            finish_reason: null,
          },
        ],
      }),
    );
    writer.write(
      sseData({
        id: this.id,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: this.model,
        choices: [
          {
            index: 0,
            delta: {
              tool_calls: [
                {
                  index,
                  id: callId,
                  type: 'function',
                  function: {
                    arguments: JSON.stringify(args),
                  },
                },
              ],
            },
            finish_reason: null,
          },
        ],
      }),
    );
    writer.write(
      sseData({
        id: this.id,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: this.model,
        choices: [
          {
            index: 0,
            delta: {},
            finish_reason: 'tool_calls',
          },
        ],
      }),
    );
  }

  /** Close stream after normal speech (no tool call). */
  finish(writer: VapiStreamWriter): void {
    writer.write(
      sseData({
        id: this.id,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model: this.model,
        choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
      }),
    );
    writer.write('data: [DONE]\n\n');
    writer.end();
  }

  /** Close stream after a tool call — do not emit finish_reason=stop. */
  finishAfterToolCalls(writer: VapiStreamWriter): void {
    writer.write('data: [DONE]\n\n');
    writer.end();
  }

  async streamTerminalActions(
    writer: VapiStreamWriter,
    actions: OutputAction[],
  ): Promise<{ emittedTools: string[] }> {
    let toolIndex = 0;
    const emittedTools: string[] = [];

    for (const action of actions) {
      if (action.kind === 'endCall') {
        const name = resolveEndCallToolName(this.tools);
        this.writeToolCall(writer, name, {}, toolIndex++);
        emittedTools.push(name);
      }
      if (action.kind === 'transferToHuman') {
        const name = resolveTransferCallToolName(this.tools);
        this.writeToolCall(
          writer,
          name,
          {
            destination:
              action.destination ?? process.env.VAPI_TRANSFER_DESTINATION,
          },
          toolIndex++,
        );
        emittedTools.push(name);
      }
    }

    if (emittedTools.length > 0) {
      this.finishAfterToolCalls(writer);
    } else {
      this.finish(writer);
    }
    return { emittedTools };
  }
}

export function extractNewestUserText(body: {
  messages?: Array<{ role?: string; content?: unknown }>;
}): string {
  const messages = body.messages ?? [];
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const msg = messages[i];
    if (msg.role === 'user') {
      if (typeof msg.content === 'string') {
        return msg.content;
      }
      if (Array.isArray(msg.content)) {
        return msg.content
          .map((part) =>
            typeof part === 'object' && part && 'text' in part
              ? String((part as { text: string }).text)
              : '',
          )
          .join(' ')
          .trim();
      }
    }
  }
  return '';
}

export function extractVapiCallId(body: Record<string, unknown>): string | null {
  const candidates: unknown[] = [
    body.callId,
    body.call_id,
    (body.call as { id?: string } | undefined)?.id,
    (body.metadata as { callId?: string } | undefined)?.callId,
    (body.metadata as { call_id?: string } | undefined)?.call_id,
    ((body as { vapi?: { call?: { id?: string } } }).vapi?.call)?.id,
  ];
  for (const value of candidates) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim();
    }
  }
  return null;
}

export function extractVapiCallerNumber(
  body: Record<string, unknown> | null | undefined,
): string | null {
  if (!body || typeof body !== 'object') return null;
  const message =
    body.message && typeof body.message === 'object'
      ? (body.message as Record<string, unknown>)
      : body;
  const call = (message.call ?? body.call) as Record<string, unknown> | undefined;
  const customer = (call?.customer ??
    message.customer ??
    body.customer) as Record<string, unknown> | undefined;
  const candidates: unknown[] = [
    customer?.number,
    customer?.phoneNumber,
    customer?.phone,
    call?.from,
    (message as { from?: unknown }).from,
    (body as { from?: unknown }).from,
  ];
  for (const value of candidates) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim();
    }
  }
  return null;
}
