import { Injectable } from '@nestjs/common';
import {
  ConversationBootstrapService,
  EventService,
} from '@guidify-ai/ra9';
import type {
  VapiStrategy,
  VapiMessageType,
  VapiWebhookCommand,
  VapiWebhookResponse,
} from '../vapi.types';

/**
 * Vapi often sends `assistant.started` (static assistant + Custom LLM)
 * instead of `assistant-request`. Bootstrap the supervised Conversation here.
 */
@Injectable()
export class CallStartedStrategy implements VapiStrategy {
  constructor(
    private readonly bootstrap: ConversationBootstrapService,
    private readonly events: EventService,
  ) {}

  supports(type: VapiMessageType): boolean {
    return (
      type === 'assistant.started' ||
      type === 'assistant-started' ||
      type === 'call.started' ||
      type === 'call-started'
    );
  }

  async handle(command: VapiWebhookCommand): Promise<VapiWebhookResponse> {
    const brainProfileId = process.env.POC_BRAIN_PROFILE || 'roofr-estimate';
    const runtime = await this.bootstrap.bootstrap({
      providerCallId: command.callId,
      brainProfileId,
      metadata: {
        messageType: command.type,
        brainProfileId,
        ...(command.callerPhoneNumber
          ? { callerPhoneNumber: command.callerPhoneNumber }
          : {}),
      },
    });

    this.events.log('info', 'CALL_STARTED_BOOTSTRAP', {
      providerCallId: command.callId,
      conversationId: runtime.conversationId,
      runtimeInstanceId: runtime.runtimeInstanceId,
      messageType: command.type,
      brainProfileId,
    });

    return { body: { ok: true } };
  }
}
