import { Injectable } from '@nestjs/common';
import type {
  ConversationEntryInput,
  ConversationEntryPoint,
  ConversationHookContext,
} from '@guidify-ai/ra9';
import type {
  RoofrConversationSchema,
  RoofrPoCVariables,
  RoofrVariables,
} from './roofr-variables';

/**
 * Conversation entry point for the Roofr PoC.
 * Seeds typed basics and setup/teardown hooks for each Conversation.
 */
@Injectable()
export class RoofrConversationEntry
  implements ConversationEntryPoint<RoofrPoCVariables>
{
  createVariables(_input: ConversationEntryInput): RoofrVariables {
    return {
      companyName: process.env.POC_COMPANY_NAME?.trim() || 'Roofr',
    };
  }

  async beforeEach(
    ctx: ConversationHookContext<RoofrPoCVariables>,
  ): Promise<void> {
    const memory = ctx.runtime.memory as RoofrConversationSchema['memory'];
    memory.conversationReady = true;
    memory.setupAt = new Date().toISOString();
  }

  async afterEach(
    ctx: ConversationHookContext<RoofrPoCVariables>,
  ): Promise<void> {
    const memory = ctx.runtime.memory as RoofrConversationSchema['memory'];
    memory.conversationReady = false;
    memory.tornDownAt = new Date().toISOString();
  }
}
