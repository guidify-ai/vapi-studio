#!/usr/bin/env bash
set -euo pipefail

ROOT="$(CDPATH="" cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PORT="${PORT:-9999}"
NGROK_API="${NGROK_API:-http://127.0.0.1:4040}"

if ! command -v docker >/dev/null 2>&1; then
  echo "docker is required" >&2
  exit 1
fi
if ! command -v ngrok >/dev/null 2>&1; then
  echo "ngrok is required on PATH" >&2
  exit 1
fi

echo ">> Starting Roofr PoC stack (Docker) on :${PORT}"
docker compose up -d --build

echo ">> Waiting for health on http://localhost:${PORT}/health"
for _ in $(seq 1 60); do
  if curl -sf "http://localhost:${PORT}/health" >/dev/null; then
    echo ">> App is healthy"
    break
  fi
  sleep 1
done
curl -sf "http://localhost:${PORT}/health" >/dev/null || {
  echo "App failed to become healthy" >&2
  docker compose logs app --tail 40 >&2 || true
  exit 1
}

cleanup() {
  if [[ -n "${NGROK_PID:-}" ]] && kill -0 "$NGROK_PID" 2>/dev/null; then
    kill "$NGROK_PID" 2>/dev/null || true
    wait "$NGROK_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

echo ">> Starting ngrok http ${PORT}"
ngrok http "$PORT" --log=stdout &
NGROK_PID=$!

public_url=""
for _ in $(seq 1 40); do
  if ! kill -0 "$NGROK_PID" 2>/dev/null; then
    echo "ngrok exited early" >&2
    exit 1
  fi
  payload="$(curl -sf "${NGROK_API}/api/tunnels" 2>/dev/null || true)"
  if [[ -n "$payload" ]]; then
    public_url="$(
      printf '%s' "$payload" | python3 -c '
import json, sys
data = json.load(sys.stdin)
https = [t.get("public_url") for t in data.get("tunnels", []) if str(t.get("public_url", "")).startswith("https://")]
print(https[0] if https else "")
'
    )"
    if [[ -n "$public_url" ]]; then
      break
    fi
  fi
  sleep 0.5
done

upsert_public_base_url() {
  local url="$1"
  if [[ ! -f .env ]]; then
    cp .env.example .env
  fi
  PUBLIC_URL="$url" python3 -c '
import os
from pathlib import Path
url = os.environ["PUBLIC_URL"]
path = Path(".env")
lines = path.read_text().splitlines()
found = False
out = []
for line in lines:
    if line.startswith("PUBLIC_BASE_URL="):
        out.append(f"PUBLIC_BASE_URL={url}")
        found = True
    else:
        out.append(line)
if not found:
    out.append(f"PUBLIC_BASE_URL={url}")
path.write_text("\n".join(out) + "\n")
'
}

if [[ -z "$public_url" ]]; then
  echo ">> Could not read ngrok public URL from ${NGROK_API}; tunnel may still be up."
  echo ">> Set PUBLIC_BASE_URL manually in .env when you see the https URL."
else
  echo ">> ngrok public URL: ${public_url}"
  upsert_public_base_url "$public_url"
  echo ">> Updated .env PUBLIC_BASE_URL and recreating app container"
  PUBLIC_BASE_URL="$public_url" docker compose up -d app
  echo
  echo "Vapi Server URL:       ${public_url}/vapi/webhook"
  echo "Vapi Custom LLM URL:   ${public_url}/vapi/chat/completions"
  echo "ngrok inspector:       http://127.0.0.1:4040"
  echo
fi

echo ">> ngrok is running (Ctrl+C stops ngrok; Docker stack keeps running)"
wait "$NGROK_PID"
