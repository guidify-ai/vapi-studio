import { readFileSync } from 'fs';
import { Injectable } from '@nestjs/common';
import { parse as parseYaml } from 'yaml';
import { DEFAULT_INTENTION_PRIORITY } from '../conversation/conversation-history';

export interface FlowNodeDefinition {
  id: string;
  class: string;
  intentions: string[];
  portal?: boolean;
  priority?: number;
  terminal?: boolean;
}

export interface FlowDefinition {
  version: number;
  id: string;
  start: string;
  nodes: Record<string, FlowNodeDefinition>;
}

export interface RawFlowFile {
  version: number;
  flow: { id: string; start: string };
  nodes: Record<
    string,
    {
      class: string;
      intentions?: string[];
      portal?: boolean;
      priority?: number;
      terminal?: boolean;
    }
  >;
}

@Injectable()
export class FlowLoader {
  private flow: FlowDefinition | null = null;

  loadFromFile(path: string): FlowDefinition {
    const raw = parseYaml(readFileSync(path, 'utf8')) as RawFlowFile;
    return this.loadFromObject(raw);
  }

  loadFromObject(raw: RawFlowFile): FlowDefinition {
    if (!raw?.flow?.id || !raw?.flow?.start || !raw?.nodes) {
      throw new Error('Invalid flow schema object');
    }
    const nodes: Record<string, FlowNodeDefinition> = {};
    for (const [id, def] of Object.entries(raw.nodes)) {
      nodes[id] = {
        id,
        class: def.class,
        intentions: def.intentions ?? [],
        portal: def.portal,
        priority: def.priority,
        terminal: def.terminal,
      };
    }
    if (!nodes[raw.flow.start]) {
      throw new Error(`Flow start node "${raw.flow.start}" missing`);
    }
    this.flow = {
      version: raw.version ?? 1,
      id: raw.flow.id,
      start: raw.flow.start,
      nodes,
    };
    return this.flow;
  }

  getFlow(): FlowDefinition {
    if (!this.flow) {
      throw new Error('Flow not loaded');
    }
    return this.flow;
  }

  nodesForIntention(intention: string): FlowNodeDefinition[] {
    const flow = this.getFlow();
    const matches = Object.values(flow.nodes).filter((n) =>
      n.intentions.includes(intention),
    );
    return matches.sort((a, b) => {
      const pa = a.priority ?? DEFAULT_INTENTION_PRIORITY;
      const pb = b.priority ?? DEFAULT_INTENTION_PRIORITY;
      if (pb !== pa) return pb - pa;
      return a.id.localeCompare(b.id);
    });
  }

  /** All intention names declared on portal nodes. */
  portalIntentionNames(): string[] {
    const flow = this.getFlow();
    const names = new Set<string>();
    for (const node of Object.values(flow.nodes)) {
      if (!node.portal) continue;
      for (const name of node.intentions) {
        names.add(name);
      }
    }
    return [...names];
  }

  /** All intention names on non-portal nodes. */
  normalIntentionNames(): string[] {
    const flow = this.getFlow();
    const names = new Set<string>();
    for (const node of Object.values(flow.nodes)) {
      if (node.portal) continue;
      for (const name of node.intentions) {
        names.add(name);
      }
    }
    return [...names];
  }
}
