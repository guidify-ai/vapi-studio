import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';
import { portalBoosts } from '../lib/portal-boosts';
import { introFirstMessage } from '../lib/intro-message';

/** Step 1 — introduce Roofr + recording consent, ask how to help. */
@Injectable()
export class AcknowledgeNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isRequestedRoofEstimate', boost: 25 },
        ...portalBoosts(),
      ],
      hints: [
        'Caller wants a roof estimate, quote, inspection, or pricing.',
        'ASR may say "roof" as "ruth" / "rough".',
      ],
      note: 'After intro, expect roof-estimate intent',
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    if (!ctx.memory.conversationReady) {
      ctx.memory.conversationReady = true;
    }
    ctx.memory.introSpoken = true;
    return ctx.output.sayAndListen(introFirstMessage());
  }
}
