/** PoC demo: always read this email back regardless of ASR. */
export const POC_DEMO_EMAIL = 'mark@roofr.com';

const NAME_STOPWORDS = new Set([
  'i',
  'me',
  'my',
  'you',
  'we',
  'they',
  'he',
  'she',
  'it',
  'a',
  'an',
  'the',
  'yes',
  'no',
  'ok',
  'okay',
  'sure',
  'yeah',
  'yep',
  'yup',
  'hi',
  'hello',
  'hey',
  'um',
  'uh',
  'and',
  'or',
]);

/** True when text looks like a spoken person name (not a sentence / pronoun). */
export function looksLikePersonName(raw: string | undefined | null): boolean {
  if (!raw) return false;
  const text = raw
    .trim()
    .replace(/[.,!?;:]+$/g, '')
    .trim();
  if (!/^[A-Za-z][A-Za-z'-]{0,30}$/.test(text)) return false;
  if (NAME_STOPWORDS.has(text.toLowerCase())) return false;
  if (/^\d+$/.test(text)) return false;
  return true;
}

/** Prefer Brain extract, then spoken text, when it looks like a person name. */
export function collectedPersonName(
  extracted: unknown,
  spoken: string,
): string {
  const fromExtract =
    typeof extracted === 'string'
      ? extracted.trim().replace(/[.,!?;:]+$/g, '')
      : '';
  const fromSpoken = spoken.trim().replace(/[.,!?;:]+$/g, '');
  if (looksLikePersonName(fromExtract)) return fromExtract;
  if (looksLikePersonName(fromSpoken)) return fromSpoken;
  return fromExtract || fromSpoken;
}

/** True when the utterance looks like picking an address match, not a day/time. */
export function looksLikeAddressChoice(userText: string): boolean {
  return parseListedChoice(userText, 3)?.kind === 'pick';
}

export type ListedChoice =
  | { kind: 'pick'; index: number }
  | { kind: 'reject' };

function listedOptionLabels(
  options: number | string[] | Array<{ label: string }>,
): string[] {
  if (typeof options === 'number') {
    return Array.from({ length: Math.max(0, options) }, (_, i) => String(i + 1));
  }
  return options.map((o) => (typeof o === 'string' ? o : o.label));
}

const LISTED_REJECT =
  /\b(neither|none of (them|those|these|the above)|neither of (them|those|these)|both wrong|not those|none of the above|none)\b/i;

/**
 * Closed listed choice: pick by ordinal / option N / unique label, or reject
 * (neither / none of those). Does not default to the first option.
 */
export function parseListedChoice(
  userText: string,
  options: number | string[] | Array<{ label: string }>,
): ListedChoice | null {
  const labels = listedOptionLabels(options);
  const t = userText
    .toLowerCase()
    .replace(/[.,!?;:]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!t) return null;

  if (LISTED_REJECT.test(t)) {
    return { kind: 'reject' };
  }

  if (/\b(first|1st)\b/.test(t)) {
    return labels.length > 0 ? { kind: 'pick', index: 0 } : null;
  }
  if (/\b(second|2nd)\b/.test(t)) {
    return labels.length > 1 ? { kind: 'pick', index: 1 } : null;
  }
  if (/\b(third|3rd)\b/.test(t)) {
    return labels.length > 2 ? { kind: 'pick', index: 2 } : null;
  }

  const optionN = t.match(
    /\b(?:option|choice|number|match|#)\s*(one|two|three|1|2|3)\b/,
  );
  if (optionN) {
    const index = listedNumberToIndex(optionN[1]);
    return index != null && index < labels.length
      ? { kind: 'pick', index }
      : null;
  }

  const unique = uniqueListedLabelIndex(t, labels);
  if (unique != null) {
    return { kind: 'pick', index: unique };
  }

  const compact = t
    .replace(
      /\b(yep|yeah|yes|ok|okay|so|it|is|did|the|a|and|my|please)\b/g,
      ' ',
    )
    .replace(/\s+/g, ' ')
    .trim();
  if (/^(one|1)$/.test(compact) && labels.length > 0) {
    return { kind: 'pick', index: 0 };
  }
  if (/^(two|2)$/.test(compact) && labels.length > 1) {
    return { kind: 'pick', index: 1 };
  }
  if (/^(three|3)$/.test(compact) && labels.length > 2) {
    return { kind: 'pick', index: 2 };
  }

  return null;
}

function listedNumberToIndex(raw: string): number | null {
  const n = raw.toLowerCase();
  if (n === 'one' || n === '1') return 0;
  if (n === 'two' || n === '2') return 1;
  if (n === 'three' || n === '3') return 2;
  return null;
}

function uniqueListedLabelIndex(text: string, labels: string[]): number | null {
  const hits: number[] = [];
  const tokens = text.split(/\s+/).filter((t) => t.length >= 4);
  for (let i = 0; i < labels.length; i++) {
    const label = labels[i].toLowerCase();
    if (label.length >= 3 && text.includes(label)) {
      hits.push(i);
      continue;
    }
    if (
      tokens.some((tok) => new RegExp(`\\b${escapeRegExp(tok)}\\b`).test(label))
    ) {
      hits.push(i);
      continue;
    }
    const house = label.match(/\d+/);
    if (house && new RegExp(`\\b${house[0]}\\b`).test(text)) {
      const others = labels.filter(
        (l, j) => j !== i && new RegExp(`\\b${house[0]}\\b`, 'i').test(l),
      );
      if (!others.length) hits.push(i);
    }
  }
  const uniq = [...new Set(hits)];
  return uniq.length === 1 ? uniq[0] : null;
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** True when the caller named a day or time preference for booking. */
export function looksLikeDayOrTimePreference(userText: string): boolean {
  const t = userText.toLowerCase();
  return /\b(today|tonight|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|morning|afternoon|evening|noon|weekend|next\s+week|\d{1,2}\s*(am|pm)|o'?clock)\b/.test(
    t,
  );
}

function fillerOnlyUtterance(userText: string): boolean {
  const cleaned = userText
    .toLowerCase()
    .replace(/[.,!?;:'"]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned) return true;
  const tokens = cleaned.split(' ').filter(Boolean);
  if (tokens.every((w) => FILLER_TOKENS.has(w))) return true;
  if (cleaned.length <= 2) return true;
  return false;
}

const FILLER_TOKENS = new Set([
  'k',
  'ok',
  'okay',
  'yes',
  'yeah',
  'yep',
  'yup',
  'no',
  'um',
  'uh',
  'and',
  'so',
  'the',
  'a',
  'i',
]);

/** Silence after the last ASR fragment before we close address dictation. */
export const ADDRESS_LISTEN_TIMEOUT_SECONDS = 3;

const STREET_TYPE =
  /\b(street|st|road|rd|avenue|ave|drive|dr|boulevard|blvd|lane|ln|way|court|ct|place|pl|circle|cir|highway|hwy|parkway|pkwy)\b/i;

const REGION =
  /\b(ontario|on|quebec|qc|qu[eé]bec|british columbia|bc|alberta|ab|manitoba|mb|saskatchewan|sk|nova scotia|ns|new brunswick|nb|pei|nl|newfoundland|yukon|nt|nunavut|california|ca|new york|ny|texas|tx|florida|fl|washington|wa|illinois|il|ohio|oh|pennsylvania|pa|georgia|ga|arizona|az|michigan|mi|massachusetts|ma|virginia|va|colorado|co|north carolina|nc|new jersey|nj)\b/i;

const NUMBER_WORDS =
  /\b(one|two|three|four|five|six|seven|eight|nine|zero|oh)\b/i;

/**
 * Cheap CA/US civic-address shape: house number, street, and city or
 * province/state. Spoken digits ("1 2 3") count as the number.
 * Borderline ASR still goes to Brain.clarify.
 */
export function looksLikeNorthAmericanAddress(raw: string): boolean {
  const t = raw.toLowerCase().replace(/[.,!?;:]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!t || fillerOnlyUtterance(t)) return false;
  const hasNumber = /\d/.test(t) || NUMBER_WORDS.test(t);
  if (!hasNumber || !STREET_TYPE.test(t)) return false;
  if (REGION.test(t)) return true;
  const leftover = t
    .replace(STREET_TYPE, ' ')
    .replace(NUMBER_WORDS, ' ')
    .replace(/\d+/g, ' ')
    .replace(
      /\b(it's|its|it is|the|at|in|of|and|my|property|address|place)\b/g,
      ' ',
    )
    .replace(/\s+/g, ' ')
    .trim();
  return leftover.split(' ').some((w) => w.length >= 3);
}

/** Instant-estimate timeline (ASAP, this month, …). Rejects ASR crumbs like "K." */
export function looksLikeProjectTimeline(userText: string): boolean {
  const t = userText.toLowerCase();
  if (fillerOnlyUtterance(t)) return false;
  return /\b(asap|soon|immediately|urgent|whenever|season|spring|summer|fall|autumn|winter|week|weeks|month|months|year|years|today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|as soon as|no rush|right away|quickly|later|next)\b/.test(
    t,
  );
}

/** Roof slope answer, including 1st/2nd/3rd of the spoken options. */
export function looksLikeRoofSlope(userText: string): boolean {
  const t = userText.toLowerCase();
  if (fillerOnlyUtterance(t)) return false;
  if (
    /\b(steep|moderate|flat|low|high|pitch|slope|rocky|mountain|gentle|normal|average|medium)\b/.test(
      t,
    )
  ) {
    return true;
  }
  return /\b(first|1st|second|2nd|third|3rd|one|two|three)\b/.test(t);
}

/**
 * Parse ASR / spelled-out emails into a normal address.
 * e.g. "m a r k at r o o f r dot com" → mark@roofr.com
 */
export function parseSpelledEmail(raw: string): string | null {
  const text = raw.trim().toLowerCase();
  if (!text) return null;

  // Already looks like an email.
  const direct = text.match(
    /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i,
  );
  if (direct) return direct[0].toLowerCase();

  const normalized = text
    .replace(/\b(at|@)\b/g, ' @ ')
    .replace(/\b(dot|period)\b/g, ' . ')
    .replace(/[^a-z0-9@.\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!normalized.includes('@')) return null;

  const [localPart, domainPart] = normalized.split('@').map((p) => p.trim());
  if (!localPart || !domainPart) return null;

  const local = localPart.replace(/\s+/g, '');
  const domain = domainPart.replace(/\s+/g, '');
  if (!local || !domain.includes('.')) return null;
  return `${local}@${domain}`;
}

export function pickAddressMatch(
  userText: string,
  matches: Array<{ id: string; label: string }>,
): { id: string; label: string } | null {
  if (!matches.length) return null;
  const parsed = parseListedChoice(userText, matches);
  if (parsed?.kind !== 'pick') return null;
  return matches[parsed.index] ?? null;
}

export function pickAppointmentSlot(
  userText: string,
  slots: string[],
): string | null {
  if (!slots.length) return null;
  const parsed = parseListedChoice(userText, slots);
  if (parsed?.kind === 'pick') {
    return slots[parsed.index] ?? null;
  }
  const t = userText.toLowerCase();
  for (const slot of slots) {
    if (t.includes(slot.toLowerCase().replace(/\s+/g, ''))) return slot;
    if (t.includes(slot.toLowerCase())) return slot;
  }
  if (/\b(earliest|nine|9)\b/.test(t)) {
    return slots.find((s) => /9/.test(s)) ?? null;
  }
  if (/\b(10|ten)\b/.test(t)) {
    return slots.find((s) => /10/.test(s)) ?? null;
  }
  if (/\b(11|eleven)\b/.test(t)) {
    return slots.find((s) => /11/.test(s)) ?? null;
  }
  return null;
}
