/**
 * Example Roofr-owned Brain adapter skeleton.
 *
 * If Roofr rejects Guidify's ChatGPT Brain, wire this (or a real HTTP client)
 * via Ra9Module.forRoot({ brainAdapter: RoofrApiBrainAdapter }).
 *
 * Supervisor never imports ChatGPT or Roofr APIs — only BRAIN_SERVICE.
 */
import { Injectable } from '@nestjs/common';
import type {
  BrainAdapter,
  BrainScanInput,
  BrainScanResult,
  BrainClarifyRequest,
  BrainClarifyResult,
  BrainJudgeRequest,
  BrainJudgeResult,
  IntentionCandidate,
} from '@guidify-ai/ra9';
import {
  applyListenBoosts,
  clarifiableInputToString,
  judgeContextToString,
  normalizeClarifyResult,
  normalizeJudgeResult,
} from '@guidify-ai/ra9';

@Injectable()
export class RoofrApiBrainAdapter implements BrainAdapter {
  async scan(input: BrainScanInput): Promise<BrainScanResult> {
    const listen = input.listen ?? input.runtime.listenExpectation;
    const baseUrl = process.env.ROOFR_BRAIN_URL?.trim();
    if (!baseUrl) {
      throw new Error(
        'RoofrApiBrainAdapter requires ROOFR_BRAIN_URL. Use MockBrainAdapter or ChatGptBrainAdapter until ready.',
      );
    }

    const res = await fetch(`${baseUrl.replace(/\/$/, '')}/intentions/scan`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(process.env.ROOFR_BRAIN_TOKEN
          ? { authorization: `Bearer ${process.env.ROOFR_BRAIN_TOKEN}` }
          : {}),
      },
      body: JSON.stringify({
        userText: input.userText,
        hints: listen?.hints ?? [],
        prioritize: listen?.intentions ?? [],
        extract: listen?.extract?.fields ?? [],
        conversationId: input.runtime.conversationId,
        providerCallId: input.runtime.providerCallId,
      }),
    });

    if (!res.ok) {
      throw new Error(`Roofr brain scan failed: ${res.status}`);
    }

    const body = (await res.json()) as {
      intentions?: IntentionCandidate[];
      extracted?: Record<string, unknown>;
    };
    const candidates = body.intentions ?? [];
    if (!candidates.length) {
      throw new Error('RoofrApiBrainAdapter returned no intentions');
    }
    return {
      intentions: applyListenBoosts(candidates, listen) as IntentionCandidate[],
      extracted: body.extracted,
    };
  }

  async clarify<TAnswer extends Record<string, unknown> = Record<string, unknown>>(
    request: BrainClarifyRequest,
  ): Promise<BrainClarifyResult<TAnswer>> {
    const baseUrl = process.env.ROOFR_BRAIN_URL?.trim();
    if (!baseUrl) {
      throw new Error(
        'RoofrApiBrainAdapter.clarify requires ROOFR_BRAIN_URL.',
      );
    }

    const res = await fetch(`${baseUrl.replace(/\/$/, '')}/clarify`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(process.env.ROOFR_BRAIN_TOKEN
          ? { authorization: `Bearer ${process.env.ROOFR_BRAIN_TOKEN}` }
          : {}),
      },
      body: JSON.stringify({
        input: clarifiableInputToString(request.input),
        question: request.question,
        answer: request.answer,
      }),
    });

    if (!res.ok) {
      throw new Error(`Roofr brain clarify failed: ${res.status}`);
    }

    const body = (await res.json()) as { answer?: Record<string, unknown> };
    return normalizeClarifyResult<TAnswer>(body, request.answer);
  }

  async judge<TContext = unknown>(
    request: BrainJudgeRequest<TContext>,
  ): Promise<BrainJudgeResult> {
    const baseUrl = process.env.ROOFR_BRAIN_URL?.trim();
    if (!baseUrl) {
      throw new Error('RoofrApiBrainAdapter.judge requires ROOFR_BRAIN_URL.');
    }

    const res = await fetch(`${baseUrl.replace(/\/$/, '')}/judge`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        ...(process.env.ROOFR_BRAIN_TOKEN
          ? { authorization: `Bearer ${process.env.ROOFR_BRAIN_TOKEN}` }
          : {}),
      },
      body: JSON.stringify({
        context: judgeContextToString(request.context),
        goals: request.goals,
        successConditions: request.successConditions,
        failureConditions: request.failureConditions,
      }),
    });

    if (!res.ok) {
      throw new Error(`Roofr brain judge failed: ${res.status}`);
    }

    return normalizeJudgeResult(await res.json(), request.options);
  }
}
