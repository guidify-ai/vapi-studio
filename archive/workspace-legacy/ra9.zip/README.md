# rA9-workspace

This repository is the **machine checkout** for RA9 work. Clone it on every laptop/CI host that will run or change the framework or a bot.

It is **not** the framework and **not** a bot. It holds:

- how the pieces fit together
- initiation specs and SpecKit artifacts
- the constitution that governs implementation
- Cursor rules/skills used while building

Code lives in sibling git repos checked out into the folders below.

## Layout

```text
rA9-workspace/                          this repo (github.com/pyskunov/rA9-workspace)
├── README.md                           you are here
├── ra9-cursor-mvp-spec.md              initiation spec (source of product intent)
├── .specify/memory/constitution.md     implementation constitution
├── specs/                              SpecKit feature specs / plans / contracts
├── packages/                           clone Guidify AI packages here
│   └── ra9/                            @guidify-ai/ra9  (repo: rA9-framework)
└── projects/                           clone RA9 applications here
    ├── README.md                       how to create a project
    └── roofr-poc/                      first app (repo: rA9-project-roofr-poc)
```

`packages/` and `projects/` are **nested repositories**. The workspace gitignores their source on purpose. After cloning this repo you still clone each package and each project into the expected path.

## Clone a working machine

```bash
git clone git@github.com:pyskunov/rA9-workspace.git guidify-ai
cd guidify-ai

git clone git@github.com:pyskunov/rA9-framework.git packages/ra9
git clone git@github.com:pyskunov/rA9-project-roofr-poc.git projects/roofr-poc
```

Apps consume the framework as a Yarn filesystem dependency, for example:

```json
{
  "dependencies": {
    "@guidify-ai/ra9": "file:../../packages/ra9"
  }
}
```

Never import RA9 internals. Application code uses the public package API only (`@guidify-ai/ra9`).

## What each layer documents

| Layer | File | Purpose |
| --- | --- | --- |
| Workspace | [`README.md`](./README.md) | Specs, constitution, clone/use this machine |
| Projects guide | [`projects/README.md`](./projects/README.md) | How to add an RA9 app; **packages list** |
| Framework | [`packages/ra9/README.md`](./packages/ra9/README.md) | RA9 runtime handbook (kept in sync with code) |
| Each app | `projects/<app>/README.md` | That app’s northern stars — not conversation schemas |

## How to use

1. Read the [constitution](./.specify/memory/constitution.md). It wins over ad-hoc habits.
2. For product intent, read [`ra9-cursor-mvp-spec.md`](./ra9-cursor-mvp-spec.md). SpecKit lean path lives under [`specs/001-ra9-vapi-poc/`](./specs/001-ra9-vapi-poc/).
3. For framework behavior, read [`packages/ra9/README.md`](./packages/ra9/README.md) after the framework checkout exists.
4. To run a bot, open that project’s README (start with [`projects/roofr-poc/README.md`](./projects/roofr-poc/README.md)). Runtime is **Docker-only** for the Nest app. Operator owns Vapi, ngrok, and secrets. Never commit `.env`.

### Typical live PoC loop

From `projects/roofr-poc`:

```bash
cp .env.example .env
# set PUBLIC_BASE_URL to your ngrok HTTPS origin
docker compose up -d --build app
curl -s http://localhost:9999/health
```

Tunnel `9999` with ngrok. Point the Vapi phone-number server URL at `/vapi/webhook` and the Custom LLM URL at `/vapi/chat/completions`. Live Brain is ChatGPT (`src/brain/brain.config.ts` `adapter: 'ra9-chatgpt'`); `.env` must contain a real `OPENAI_API_KEY`. Live turns must be fast (first speech <1.5s; no pre-scan hold). Vapi stale repeats and weird callers are shit-in-shit-out — not in scope to fully handle.

## Guidify AI packages

RA9 is the first package in a private family (`@guidify-ai/<name>`). Future reusable packages also clone under `packages/`. When that list changes, update [`projects/README.md`](./projects/README.md) (projects depend on those packages).

## Cursor

Project rules under `.cursor/rules/` encode documentation and Node conventions. Framework README updates are a **hard rule** whenever `@guidify-ai/ra9` changes.
