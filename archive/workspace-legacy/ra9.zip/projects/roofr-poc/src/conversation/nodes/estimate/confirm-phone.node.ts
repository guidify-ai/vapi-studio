import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';

/** Confirm the inbound caller ID / calling number is OK to use. */
@Injectable()
export class ConfirmPhoneNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isConfirmedPhone', boost: 20 }, ...portalBoosts()],
      hints: [
        'Yes/yeah/correct means phone confirmed; no means they want a different number.',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    if (!ctx.memory.lastName?.trim()) {
      const spoken = ctx.userText.trim().replace(/[.,!?;:]+$/g, '');
      if (spoken) {
        ctx.memory.lastName = spoken;
      }
    }

    return ctx.output.sayAndListen(
      "Is the phone number you're calling from the best number to reach you?",
      {
        extract: {
          fields: [
            {
              key: 'phoneOk',
              type: 'boolean',
              required: true,
              description: 'True if calling number is OK',
            },
          ],
          onExtracted: (data) => {
            ctx.memory.phoneConfirmed =
              data.phoneOk === true || data.phoneOk === 'true';
          },
        },
      },
    );
  }
}
