import type {
  ConversationSchema,
  Variables,
} from '@guidify-ai/ra9';

/**
 * Roofr PoC conversation variables — seeded once at Conversation entry.
 */
export interface RoofrPoCVariables {
  companyName: string;
}

export interface RoofrAddressMatchMemory {
  id: string;
  label: string;
}

/**
 * Roofr PoC working memory — mutated by Nodes / entry hooks during the call.
 */
export interface RoofrPoCMemory {
  conversationReady?: boolean;
  setupAt?: string;
  tornDownAt?: string;
  /** Legacy / short display name. */
  callerName?: string;
  callerIntent?: string;
  madStrikes?: number;
  unknownTransitionCount?: number;

  /** Estimate intake */
  introSpoken?: boolean;
  firstName?: string;
  lastName?: string;
  phoneConfirmed?: boolean;
  addressQuery?: string;
  addressCollectAttempts?: number;
  addressMatches?: RoofrAddressMatchMemory[];
  selectedAddress?: string;
  selectedAddressId?: string;
  wantsAppointment?: boolean;
  appointmentDayHint?: string;
  availableSlots?: string[];
  /** Active numbered list the caller is choosing from (pick N / neither). */
  listedChoice?: {
    labels: string[];
    pickIntention: string;
    rejectIntention: string;
  };
  selectedSlot?: string;
  appointmentConfirmationId?: string;
  email?: string;
  emailConfirmed?: boolean;
  wantsInstantEstimate?: boolean;
  projectTimeline?: string;
  roofSlope?: string;
  estimateLow?: number;
  estimateHigh?: number;
}

/**
 * Full Roofr Conversation schema — pass to Ra9Node / NodeContext generics.
 */
export interface RoofrConversationSchema extends ConversationSchema {
  variables: RoofrPoCVariables;
  memory: RoofrPoCMemory;
}

export type RoofrVariables = Variables<RoofrPoCVariables>;
