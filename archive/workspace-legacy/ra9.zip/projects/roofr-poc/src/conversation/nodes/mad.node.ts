import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  RA9_INTENTIONS,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

/**
 * Standalone portal for angry/mad callers (Replicant-style `isMad`).
 * Intercepts normal flow, de-escalates, then listens — origin preserved.
 */
@Injectable()
export class MadNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isContinue', boost: 15 },
        { name: RA9_INTENTIONS.isTransferToHuman, boost: 20 },
        { name: RA9_INTENTIONS.isGoodbye, boost: 10 },
        { name: RA9_INTENTIONS.isMad, boost: 25 },
      ],
      hints: [
        'Caller was angry — if still heated, keep mad / offer human.',
        'If they calm down (okay/fine/sorry), prefer continue.',
        'ASR: "mad"/"angry"/"pissed"/"ridiculous"/"waste of time"/"supervisor".',
      ],
      note: 'Mad portal de-escalation listen',
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const strikes = (ctx.memory.madStrikes ?? 0) + 1;
    ctx.memory.madStrikes = strikes;

    await ctx.events.persist(ctx.runtime.conversationId, 'MAD_ENTER', {
      runtimeInstanceId: ctx.runtime.runtimeInstanceId,
      originNodeId: ctx.runtime.portalState.originNodeId,
      activePortalId: ctx.runtime.portalState.activePortalId,
      madStrikes: strikes,
    });

    if (strikes >= 2) {
      return ctx.output.sayAndListen(
        "I hear how frustrated you are. I can connect you to a person if you'd like — or we can keep going. What do you prefer?",
      );
    }

    return ctx.output.sayAndListen(
      "I'm sorry you're dealing with this. I want to make it right — tell me what's going on, and I'll help.",
    );
  }
}
