import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { addressCollectListen, reaskAddress } from '../../lib/address-collect';
import { listedChoiceIsReject, clearListedChoice } from '../../lib/listed-choice-listen';

/** Caller rejected every listed address match — collect a new address. */
@Injectable()
export class RejectAddressMatchNode extends Ra9Node<RoofrConversationSchema> {
  async before(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<boolean> {
    return listedChoiceIsReject(
      ctx.userText,
      ctx.memory as Record<string, unknown>,
    );
  }

  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return addressCollectListen();
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    ctx.memory.addressMatches = undefined;
    ctx.memory.selectedAddress = undefined;
    ctx.memory.selectedAddressId = undefined;
    ctx.memory.addressQuery = undefined;
    clearListedChoice(ctx);
    await ctx.output.say('Okay — none of those.');
    return reaskAddress(ctx);
  }
}
