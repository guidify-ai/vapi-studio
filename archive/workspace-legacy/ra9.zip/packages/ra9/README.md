# RA9 (`@guidify-ai/ra9`)

Code-first NestJS framework for **stateful conversational bots**.

RA9 is not a no-code builder and not a mega-prompt. Conversation orchestration is typed application code + a small YAML path file + a Brain used only where interpretation is useful.

This README is the **living framework handbook**. It must match shipped behavior. Any change to this package updates this file in the same work (Cursor hard rule).

- Package repo: [pyskunov/rA9-framework](https://github.com/pyskunov/rA9-framework)
- Clone path in the workspace: `packages/ra9` inside [rA9-workspace](https://github.com/pyskunov/rA9-workspace)
- Initiation spec (product intent): `ra9-cursor-mvp-spec.md` in the workspace
- Constitution: workspace `.specify/memory/constitution.md`
- Apps: see workspace `projects/README.md`

Roofr-specific Nodes, copy, and flows do **not** belong here.

## What RA9 is

```text
channel adapter (Vapi, later others)
        ↓
orchestrator (Conversation / Supervisor / Nodes)
        ↓
Brain adapter (mock | ChatGPT | app-owned HTTP)
```

A bot is a normal NestJS application:

- **Framework** — Supervisor, Node contracts, Brain port, events, persistence, Vapi adapter, conventions
- **Application** — `flow.yaml`, Node classes, domain services, prompts, env, Docker

Applications import **only** from `@guidify-ai/ra9` (this package’s public exports). They must not reach into private source paths or re-implement provider SSE.

## Consume

```json
{
  "dependencies": {
    "@guidify-ai/ra9": "file:../../packages/ra9"
  }
}
```

Build the package (`yarn build` → `dist/`) before the app type-checks against it. App runtime is Docker-only in the current PoC; Yarn in Docker is the supported install path.

Wire Nest:

```ts
Ra9Module.forRoot({
  nodes: [{ className: 'GoodbyeNode', useClass: GoodbyeNode }],
  entryPoint: MyConversationEntry,
  brainAdapter: MockBrainAdapter,        // or ChatGptBrainAdapter / app class
  brain: {
    model: 'gpt-4.1-nano',               // cheap whitelist; not .env
    confidenceThreshold: 0.4,
  },
  eventListeners: [],
})
```

## Architecture

| Piece | Role |
| --- | --- |
| **Conversation** | One durable identity per provider call (`providerCallId`) + one in-memory `SupervisedConversation` for the live call |
| **Supervisor** | Each user turn: scan intentions → walk candidates → `before()` → `listen()` → `run()` → `after()` |
| **Node** | Application class. Owns speech, memory writes, integrations, terminal action |
| **Flow YAML** | Paths only: start node, class names, intention names, portal flags, priority |
| **Brain** | `scan` / `clarify` / `judge`. Does not own routing |
| **Adapter** | Channel wire format (Vapi Custom LLM SSE, call id, tools). Nodes never see it |
| **Events** | `EventService.emit` → console + listeners (Postgres by default) |
| **Integrations** | Signed outbound HTTP from Nodes via `ctx.integrations.request` |

Happy-path live call (MVP): bootstrap → in-memory runtime reused across Custom LLM turns → `status-update: ended` finalize. Crash recovery, multi-process Supervisor, and replay-after-restart are **out of scope**.

## Conversation lifecycle

1. Channel bootstrap (`assistant-request`, `assistant.started`, lazy Custom LLM, or early `status-update`) calls `ConversationBootstrapService.bootstrap({ providerCallId, brainProfileId, metadata })`.
2. Postgres row `conversations` (ACTIVE) + in-memory `SupervisedConversation` with a `runtimeInstanceId`. Concurrent bootstrap for the same call is serialized and reused.
3. Optional `ConversationEntryPoint.createVariables` + `beforeEach`.
4. Each Custom LLM turn: correlate call id → same runtime → `Supervisor.handleTurn`.
5. `status-update: ended` → `afterEach` → persist final snapshot → drop registry + turn queue.

Identity is the **provider call id**. One supervised runtime per active call.

## Supervisor routing

Every user turn is scanned **before** normal Node execution, unless the active listen's `resolveIntention` cheap-matches a listed intention (then Brain is skipped).

**Candidates** = current listen intentions + all portal intentions + `ra9.isUnknownTransition` (priority `0` as the unknown fallback identity). Chat Completions is stateless: compact history on the runtime is resent; there is no OpenAI `previous_response_id`.

**Brain `scan`** returns scores in `[0, 1]` at 6 decimal places. Listen `boost` is a scoring **hint** only. It does not change Supervisor walk order.

**Walk order** (first `before() === true` wins):

1. Drop scores below `brain.confidenceThreshold` (default `0.4`), except keep unknown
2. Remaining: `priority` descending (default `1`), then intention name A–Z

`before()` returning `false` continues to the next walkable candidate. Compact history is on `SupervisedConversation` (`ctx.history`, `ctx.previousNodeId`, `ctx.visitCount()`).

Opening turn with empty user text still runs `flow.start` (speak-first). Overlapping Custom LLM requests for one call are serialized by `CallTurnQueue` (coalesced user speech).

## Nodes

`Ra9Node<TSchema>` — declare overrides in **runtime order**:

1. `before(ctx)` — authorize / prepare; `false` rejects this candidate
2. `listen(ctx)` — register the **next** listen (intentions, hints, extract, optional `timeoutSeconds`) **before** speech so mid-talk interrupts still bind
3. `run(ctx)` — **required**; must end the turn with a terminal output action
4. `after(ctx, result)` — teardown for this execution
5. `catch(ctx, error)` — optional recovery (`restartNode`, `forceIntention`, `catchResult`, `rethrowCatch`)

Intention **action** names: `is{VerbInPast}…` (`isCollectedFirstName`). Polarity adjectives are fine (`ra9.isPositive`).

`ctx` includes typed `memory` / `conversation.variables`, `output`, `events`, `clarify`, `judge`, `integrations`, history helpers.

### Listen timeout

How long the channel waits after a user pause before closing the listen (so ASR crumbs like `"K."` do not steal the turn from `"as soon as possible"`).

| Layer | Where | Wins over |
| --- | --- | --- |
| Framework default | `DEFAULT_LISTEN_TIMEOUT_SECONDS` (`2.5`) | — |
| Node class | `listenTimeoutSeconds` on the `Ra9Node` subclass | default |
| `listen()` | `ListenExpectation.timeoutSeconds` | Node class |
| `sayAndListen({ timeoutSeconds })` | that turn only | `listen()` |

Clamped to `[0.4, 12]`. The Supervisor stamps the resolved value onto `runtime.listenExpectation`. Transient `assistant-request` assistants get a matching Vapi `startSpeakingPlan`. **Do not hold the Custom LLM request** when the Brain is ChatGPT — that delay plus OpenAI latency makes Vapi retry and the caller repeat. **Exception:** a listen with `interruptible: false` (address dictation) queues overlapping Custom LLM POSTs until **3s of silence** after the last fragment, then scans once. Mock Brain may still pass `listenHoldMs` to coalesce ASR crumbs. ChatGPT scans abort after **3s** and fall back to `ra9.isUnknownTransition`. Target: first SSE speech **< 1.5s** after the Custom LLM request (live conversation — silence is a failure). **Speech must land on the Custom LLM HTTP request Vapi is still listening to.** A queued/coalesced waiter replays `lastAssistantSpeech`; it must not finish with empty SSE. **Shit in, shit out:** Vapi duplicate/stale Custom LLM posts are a provider artifact — do not teach scan prompts or Nodes to detect “stale repeats.” Garbage ASR and weird callers are not fully in scope; unknown / re-ask is enough.

Override on the class:

```ts
export class AskTimelineNode extends Ra9Node {
  listenTimeoutSeconds = 3.5;
}
```

### Output (terminal invariant)

A Node may `say()` several times in one turn. It must finish with exactly one of:

- `sayAndListen(text, options?)` — speak and wait (optional `extract`, `timeoutSeconds`, `onExtracted` that **the app** writes into memory)
- `endCall(text?)`
- `transferToHuman(destination?)`

The Vapi adapter compiles those actions to OpenAI-compatible SSE + tool calls (`end_call_tool`, `transferCall`). Tool names are env-configurable.

### Listen / extract

`listen()` / `sayAndListen({ extract })` tell Brain what to score and which JSON fields to pull. The framework does not auto-assign memory: `onExtracted` is application-owned. Listen timeout is documented above.

**Closed choice (`resolveIntention`)** — after the bot listed numbered options, attach a cheap matcher on the listen. If it returns an intention name that is on that listen, Supervisor **skips Brain** and walks that intention at confidence 1 (no 3s abort). Return `null` to fall through to Brain so portals and unknown still work. Use this for pick-N / neither, not for free-form answers. A skipped scan still advances `brainSequenceIndex` so MockBrain sequences stay aligned.

```ts
return ctx.output.sayAndListen('I have two matches. Which one is correct?', {
  resolveIntention: ({ userText, memory }) => {
    // 'isConfirmedAddressMatch' | 'isRejectedAddressMatch' | null
  },
});
```

## Flow YAML

YAML describes **paths**, not implementations. No URLs, no integration payloads.

```yaml
version: 1
flow:
  id: my-bot
  start: acknowledge
nodes:
  acknowledge:
    class: AcknowledgeNode
    intentions:
      - isAcknowledged
  goodbye:
    class: GoodbyeNode
    intentions:
      - ra9.isGoodbye
    terminal: true
  transferToHuman:
    class: TransferToHumanNode
    portal: true
    priority: 100
    intentions:
      - ra9.isTransferToHuman
```

- Exactly one `start`
- `class` maps to `Ra9Module.forRoot({ nodes: [{ className, useClass }] })`
- `portal: true` — eligible every turn, not only from the current listen
- `priority` on the node feeds Supervisor walk (with listen-level priority)

## Brain

Port (`BrainService` / `BrainAdapter`) — Supervisor depends only on this:

| Method | Use |
| --- | --- |
| `scan` | Rank candidates + optional `extracted` map |
| `clarify` | Structured Q&A; always `{ answer: object }` |
| `judge` | LLM-as-a-judge for **evals**; rare on the live path |

Judge result: `{ passed, confidence, reasoning, belowThreshold }`. `confidence` is always `/^\d\.\d{6}$/`. Threshold does **not** flip `passed`. Trusted pass = `passed && !belowThreshold`. Paid e2e evals are not in the current delivery slice.

Stock adapters:

- `MockBrainAdapter` — deterministic sequences / profiles (PoC default)
- `ChatGptBrainAdapter` — cheap OpenAI whitelist only (`gpt-4.1-nano`, `gpt-4o-mini`, `gpt-4.1-mini`, `gpt-5.4-nano`). Scan HTTP timeout **3s**; failure → unknown. Live path: no pre-scan hold; first speech target **< 1.5s**. Do not special-case Vapi stale repeats in the scan prompt. Enable in **application code**.

Apps may supply their own adapter (e.g. HTTP Brain) via `brainAdapter`.

Brain **model** and **scan threshold** are `Ra9Module.forRoot({ brain })`. Only `OPENAI_API_KEY` belongs in `.env`. End of call may log `BRAIN_COST_SUMMARY` when the ChatGPT adapter recorded usage.

## Standard intentions and portals

Package-owned **names** (behavior is always an application Node):

| Constant | Name |
| --- | --- |
| `RA9_INTENTIONS.isGoodbye` | `ra9.isGoodbye` |
| `RA9_INTENTIONS.isTransferToHuman` | `ra9.isTransferToHuman` |
| `RA9_INTENTIONS.isPause` | `ra9.isPause` |
| `RA9_INTENTIONS.isMad` | `ra9.isMad` |
| `RA9_INTENTIONS.isUnknownTransition` | `ra9.isUnknownTransition` |
| `RA9_INTENTIONS.isPositive` | `ra9.isPositive` |
| `RA9_INTENTIONS.isNegative` | `ra9.isNegative` |

Portals are global Nodes (`portal: true`). Transfer-to-human typically re-engages **once** in memory, then emits `transferToHuman`. Portal counters are in-memory on the active runtime, not the durable turn source of truth.

## Channel adapter (Vapi)

Vapi treats the app as an OpenAI-compatible Custom LLM.

- Webhook: server messages (`assistant-request`, `assistant.started`, `status-update`, `user-interrupted`, …). Strategies live in the **app**; helpers live here (`extractVapiCallId`, `extractVapiCallerNumber`).
- Custom LLM: `POST …/chat/completions` — **one request per turn**, SSE stream, then close. `VapiSseCompiler` writes chunks and terminal tool calls. Mock Brain may hold `listenTimeoutSeconds` to coalesce ASR crumbs; ChatGPT must not — scan starts immediately.
- Correlation: call id from body/headers. Missing call id is an error, not a silent new Conversation.

Nodes speak through `ConversationOutput`. They never format SSE.

## Integrations

```ts
await ctx.integrations.request({
  name: 'example.slots',
  url: 'https://example.test/v1/slots',
  body: { day: 'tomorrow' },
  secretEnvKey: 'EXAMPLE_JWT_SECRET', // name of the .env key, not the secret
});
```

JWT HS256 of the canonical body bytes in `x-signature` (Node `crypto`, no `jsonwebtoken`). Events: `INTEGRATION_REQUEST` / `INTEGRATION_RESPONSE` / `INTEGRATION_ERROR`.

## Events, console, daily logs

`EventService.emit` / `.log` → pretty conversation console **and** registered listeners.

- Default listener: `PostgresEventListener` → `conversation_events`
- Extra listeners: `Ra9Module.forRoot({ eventListeners: [...] })`
- Console: `RA9_CONSOLE_DEBUG` (default on). Disable with `0` / `false` / `off`
- File driver: still prints console; also appends ANSI-stripped lines to `{LOG_DIR}/dailyYYYYMMDD.log`
- **The log directory is owned by the application** (each project keeps a `logs/` folder and sets `LOG_DIR`). The framework only writes there.
- Retention: `LOG_DAYS` (default **14**). Files at or older than that are deleted
- Each call writes a banner once:

```text
--------------------
Call ID: {vapi_call_id}
Caller Phone Number: {webhook customer number, or blank}

```

Disable file logs with `RA9_FILE_LOG=0`. Tests skip files unless `LOG_DIR` is set.

## Persistence (PoC)

TypeORM + PostgreSQL:

- `conversations` — durable identity, status, metadata, final snapshot
- `conversation_events` — event history
- `provider_ingress` — raw webhook / Custom LLM bodies for operator inspection

Active-call state (portal counters, listen registration, turn queue) stays **in memory**.

## Public API (start here)

Export surface is `src/index.ts`. Important groups:

- `Ra9Module`, `Ra9Node`, `NodeContext`, `Supervisor`
- `ConversationBootstrapService`, `SupervisedConversation`, registries, `CallTurnQueue`
- `ConversationEntryPoint`, schema/history types
- `BrainService` / adapters / `RA9_INTENTIONS` / `Ra9BrainConfig`
- `FlowLoader`
- `EventService`, daily-log helpers
- `IntegrationClient`, JWT helpers
- `VapiSseCompiler`, `extractVapiCallId`, `extractVapiCallerNumber`
- Listen timeout: `DEFAULT_LISTEN_TIMEOUT_SECONDS`, `Ra9Node.listenTimeoutSeconds`, `Ra9Node.interruptible`, `listenTimeoutToVapiStartSpeakingPlan`
- Catch helpers: `restartNode`, `forceIntention`, `FlowUncertainError`

## Env the framework reads

| Variable | Default | Meaning |
| --- | --- | --- |
| `OPENAI_API_KEY` | — | ChatGPT adapter secret only |
| `RA9_CONSOLE_DEBUG` | on | Pretty stdout |
| `RA9_FILE_LOG` | on | Daily files |
| `LOG_DIR` | `logs` | Directory the **app** owns (project `logs/`); framework writes `dailyYYYYMMDD.log` here |
| `LOG_DAYS` | `14` | Retention |
| `VAPI_END_CALL_TOOL_NAME` | `end_call_tool` | End-call tool (must match the Vapi tool name) |
| `VAPI_TRANSFER_CALL_TOOL_NAME` | `transferCall` | Transfer tool |

Apps add their own env (database URL, public base URL, Brain profile, transfer destination). Document those in the **project** README / `.env.example`, not here, unless the framework starts reading them.

## Tests

```bash
yarn test   # tsc + node:test under test/*.test.mjs
```

Mocked unit tests; no live Vapi or paid Brain unless a future eval slice says so.

## Out of scope (current MVP)

Multi-process runtime registry, crash recovery, failover, generic CLI app generator, production Roofr business logic, default-on ChatGPT.
