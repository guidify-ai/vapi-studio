import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { introFirstMessage } from '../../lib/intro-message';
import { collectedPersonName } from '../../lib/estimate-parse';

/** Step 2–3 — acknowledge estimate ask, begin intake, ask first name. */
@Injectable()
export class RoofEstimateIntentNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isCollectedFirstName', boost: 20 }, ...portalBoosts()],
      hints: ['Caller is answering with their first name.'],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    // Safety: never skip company intro if Acknowledge did not run first.
    if (!ctx.memory.introSpoken) {
      await ctx.output.say(introFirstMessage());
      ctx.memory.introSpoken = true;
    }

    ctx.memory.callerIntent = 'roof_estimate';
    await ctx.output.say('I can help you with that.');
    await ctx.output.say('I need to collect some information from you first.');
    return ctx.output.sayAndListen("What's your first name?", {
      extract: {
        fields: [
          {
            key: 'firstName',
            type: 'string',
            required: true,
            description: 'Caller first name',
          },
        ],
        onExtracted: (data, apply) => {
          const name = collectedPersonName(data.firstName, apply.userText);
          if (name) {
            ctx.memory.firstName = name;
            ctx.memory.callerName = name;
          }
        },
      },
    });
  }
}
