import type { ListenExpectation, NodeContext } from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';
import { portalBoosts } from './portal-boosts';
import { parseListedChoice } from './estimate-parse';

/** Spoken closer — every listed-option question uses this sentence. */
export const LISTED_CHOICE_CLOSER =
  'Which one is correct? First, second, or neither?';

export const SLOPE_CHOICE_LABELS = [
  'steep',
  'a moderate slope',
  'rocky mountain',
] as const;

export interface ListedChoiceSpec {
  intro: string;
  labels: string[];
  pickIntention: string;
  rejectIntention: string;
}

export interface ListedChoiceMemory {
  labels: string[];
  pickIntention: string;
  rejectIntention: string;
}

function listedChoiceFromMemory(
  memory: Record<string, unknown>,
): ListedChoiceMemory | null {
  const spec = memory.listedChoice as ListedChoiceMemory | undefined;
  if (spec?.labels?.length && spec.pickIntention && spec.rejectIntention) {
    return spec;
  }
  const matches = memory.addressMatches as
    | Array<{ label: string }>
    | undefined;
  if (Array.isArray(matches) && matches.length) {
    return {
      labels: matches.map((m) => m.label),
      pickIntention: 'isConfirmedAddressMatch',
      rejectIntention: 'isRejectedAddressMatch',
    };
  }
  const slots = memory.availableSlots as string[] | undefined;
  if (Array.isArray(slots) && slots.length) {
    return {
      labels: slots,
      pickIntention: 'isSelectedAppointmentSlot',
      rejectIntention: 'isRejectedAppointmentSlot',
    };
  }
  return null;
}

/** `I have several matches: 1) A, and 2) B. Which one is correct? First, second, or neither?` */
export function listedChoiceQuestion(intro: string, labels: string[]): string {
  const list = labels.map((label, i) => `${i + 1}) ${label}`).join(', and ');
  return `${intro} ${list}. ${LISTED_CHOICE_CLOSER}`;
}

export function resolveListedChoiceIntention(
  userText: string,
  memory: Record<string, unknown>,
): string | null {
  const spec = listedChoiceFromMemory(memory);
  if (!spec) return null;
  const parsed = parseListedChoice(userText, spec.labels);
  if (parsed?.kind === 'pick') return spec.pickIntention;
  if (parsed?.kind === 'reject') return spec.rejectIntention;
  return null;
}

/** Closed-set listen for a numbered list. Always pick-N or neither. */
export function listedChoiceListen(
  spec?: ListedChoiceMemory | null,
): ListenExpectation {
  const pair = spec
    ? [
        { name: spec.pickIntention, boost: 20 },
        { name: spec.rejectIntention, boost: 20 },
      ]
    : [
        { name: 'isConfirmedAddressMatch', boost: 20 },
        { name: 'isRejectedAddressMatch', boost: 20 },
        { name: 'isSelectedAppointmentSlot', boost: 20 },
        { name: 'isRejectedAppointmentSlot', boost: 20 },
        { name: 'isCollectedSlope', boost: 20 },
        { name: 'isRejectedSlope', boost: 20 },
      ];
  return {
    intentions: [...pair, ...portalBoosts()],
    hints: [
      'Closed choice: first, second, 1, 2, option one, or neither / none of those.',
    ],
    resolveIntention: ({ userText, memory }) =>
      resolveListedChoiceIntention(userText, memory),
  };
}

/** Address-only alias — same listen as every other listed choice. */
export function addressChoiceListen(): ListenExpectation {
  return listedChoiceListen();
}

export function clearListedChoice(
  ctx: NodeContext<RoofrConversationSchema>,
): void {
  ctx.memory.listedChoice = undefined;
}

export function openListedChoice(
  ctx: NodeContext<RoofrConversationSchema>,
  spec: ListedChoiceSpec,
): { text: string; listen: ListenExpectation } {
  ctx.memory.listedChoice = {
    labels: spec.labels,
    pickIntention: spec.pickIntention,
    rejectIntention: spec.rejectIntention,
  };
  return {
    text: listedChoiceQuestion(spec.intro, spec.labels),
    listen: listedChoiceListen(ctx.memory.listedChoice),
  };
}

export function listedChoiceIsReject(
  userText: string,
  memory: Record<string, unknown>,
): boolean {
  const spec = listedChoiceFromMemory(memory);
  if (!spec) return false;
  return parseListedChoice(userText, spec.labels)?.kind === 'reject';
}
