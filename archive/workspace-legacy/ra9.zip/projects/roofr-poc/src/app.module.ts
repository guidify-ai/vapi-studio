import { Inject, Logger, Module, OnModuleInit } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { join } from 'path';
import {
  BRAIN_SERVICE,
  ChatGptBrainAdapter,
  ConversationEntity,
  ConversationEventEntity,
  FlowLoader,
  MockBrainAdapter,
  ProviderIngressEntity,
  Ra9Module,
  type BrainAdapter,
} from '@guidify-ai/ra9';
import { HealthController } from './health/health.controller';
import { VapiController } from './vapi/vapi.controller';
import { VapiWebhookGuard } from './vapi/vapi.guard';
import { VapiWebhookHandler } from './vapi/vapi.handler';
import { VapiStrategyTriager } from './vapi/vapi.triager';
import { AssistantRequestStrategy } from './vapi/strategies/assistant-request.strategy';
import { CallStartedStrategy } from './vapi/strategies/call-started.strategy';
import { StatusUpdateStrategy } from './vapi/strategies/status-update.strategy';
import { UserInterruptedStrategy } from './vapi/strategies/user-interrupted.strategy';
import { AcknowledgeNode } from './conversation/nodes/acknowledge.node';
import { AlwaysRejectNode } from './conversation/nodes/always-reject.node';
import { MultiSayNode } from './conversation/nodes/multi-say.node';
import { InterruptTestNode } from './conversation/nodes/interrupt-test.node';
import { ContinueNode } from './conversation/nodes/continue.node';
import { GoodbyeNode } from './conversation/nodes/goodbye.node';
import { PauseNode } from './conversation/nodes/pause.node';
import { MadNode } from './conversation/nodes/mad.node';
import { UnknownTransitionNode } from './conversation/nodes/unknown-transition.node';
import { TransferToHumanNode } from './conversation/nodes/transfer-to-human.node';
import { RoofEstimateIntentNode } from './conversation/nodes/estimate/roof-estimate-intent.node';
import { AskLastNameNode } from './conversation/nodes/estimate/ask-last-name.node';
import { ConfirmPhoneNode } from './conversation/nodes/estimate/confirm-phone.node';
import { PromptAddressNode } from './conversation/nodes/estimate/prompt-address.node';
import { ResolveAddressNode } from './conversation/nodes/estimate/resolve-address.node';
import { ConfirmAddressMatchNode } from './conversation/nodes/estimate/confirm-address-match.node';
import { RejectAddressMatchNode } from './conversation/nodes/estimate/reject-address-match.node';
import { AskAppointmentAvailabilityNode } from './conversation/nodes/estimate/ask-appointment-availability.node';
import { DeclineAppointmentNode } from './conversation/nodes/estimate/decline-appointment.node';
import { CheckAvailabilityNode } from './conversation/nodes/estimate/check-availability.node';
import { RejectAppointmentSlotNode } from './conversation/nodes/estimate/reject-appointment-slot.node';
import { BookAppointmentNode } from './conversation/nodes/estimate/book-appointment.node';
import { ConfirmEmailNode } from './conversation/nodes/estimate/confirm-email.node';
import { OfferInstantEstimateNode } from './conversation/nodes/estimate/offer-instant-estimate.node';
import { AskTimelineNode } from './conversation/nodes/estimate/ask-timeline.node';
import { AskSlopeNode } from './conversation/nodes/estimate/ask-slope.node';
import { RejectSlopeNode } from './conversation/nodes/estimate/reject-slope.node';
import { DeliverEstimateNode } from './conversation/nodes/estimate/deliver-estimate.node';
import { RoofrConversationEntry } from './conversation/roofr-conversation-entry';
import { RoofrApiBrainAdapter } from './brain/roofr-api-brain.adapter';
import { brainConfig } from './brain/brain.config';

function resolveBrainAdapter() {
  switch (brainConfig.adapter) {
    case 'ra9-chatgpt':
      return ChatGptBrainAdapter;
    case 'roofr':
      return RoofrApiBrainAdapter;
    case 'mock':
    default:
      return MockBrainAdapter;
  }
}

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      url:
        process.env.DATABASE_URL ??
        'postgres://ra9:ra9@postgres:5432/ra9',
      entities: [
        ConversationEntity,
        ConversationEventEntity,
        ProviderIngressEntity,
      ],
      synchronize: true,
    }),
    Ra9Module.forRoot({
      entryPoint: RoofrConversationEntry,
      brainAdapter: resolveBrainAdapter(),
      brain: {
        model: brainConfig.model,
        confidenceThreshold: brainConfig.confidenceThreshold,
      },
      nodes: [
        { className: 'AcknowledgeNode', useClass: AcknowledgeNode },
        { className: 'RoofEstimateIntentNode', useClass: RoofEstimateIntentNode },
        { className: 'AskLastNameNode', useClass: AskLastNameNode },
        { className: 'ConfirmPhoneNode', useClass: ConfirmPhoneNode },
        { className: 'PromptAddressNode', useClass: PromptAddressNode },
        { className: 'ResolveAddressNode', useClass: ResolveAddressNode },
        { className: 'ConfirmAddressMatchNode', useClass: ConfirmAddressMatchNode },
        { className: 'RejectAddressMatchNode', useClass: RejectAddressMatchNode },
        {
          className: 'AskAppointmentAvailabilityNode',
          useClass: AskAppointmentAvailabilityNode,
        },
        { className: 'DeclineAppointmentNode', useClass: DeclineAppointmentNode },
        { className: 'CheckAvailabilityNode', useClass: CheckAvailabilityNode },
        { className: 'RejectAppointmentSlotNode', useClass: RejectAppointmentSlotNode },
        { className: 'BookAppointmentNode', useClass: BookAppointmentNode },
        { className: 'ConfirmEmailNode', useClass: ConfirmEmailNode },
        { className: 'OfferInstantEstimateNode', useClass: OfferInstantEstimateNode },
        { className: 'AskTimelineNode', useClass: AskTimelineNode },
        { className: 'AskSlopeNode', useClass: AskSlopeNode },
        { className: 'RejectSlopeNode', useClass: RejectSlopeNode },
        { className: 'DeliverEstimateNode', useClass: DeliverEstimateNode },
        { className: 'AlwaysRejectNode', useClass: AlwaysRejectNode },
        { className: 'MultiSayNode', useClass: MultiSayNode },
        { className: 'ContinueNode', useClass: ContinueNode },
        { className: 'InterruptTestNode', useClass: InterruptTestNode },
        { className: 'GoodbyeNode', useClass: GoodbyeNode },
        { className: 'PauseNode', useClass: PauseNode },
        { className: 'MadNode', useClass: MadNode },
        { className: 'UnknownTransitionNode', useClass: UnknownTransitionNode },
        { className: 'TransferToHumanNode', useClass: TransferToHumanNode },
      ],
    }),
  ],
  controllers: [HealthController, VapiController],
  providers: [
    VapiWebhookGuard,
    VapiWebhookHandler,
    VapiStrategyTriager,
    AssistantRequestStrategy,
    CallStartedStrategy,
    StatusUpdateStrategy,
    UserInterruptedStrategy,
  ],
})
export class AppModule implements OnModuleInit {
  private readonly logger = new Logger(AppModule.name);

  constructor(
    private readonly flowLoader: FlowLoader,
    @Inject(BRAIN_SERVICE) private readonly brain: BrainAdapter,
  ) {}

  onModuleInit(): void {
    const configDir = process.env.CONFIG_DIR ?? join(process.cwd(), 'config');
    this.flowLoader.loadFromFile(join(configDir, 'flow.yaml'));

    this.logger.log(
      `Brain driver=${brainConfig.adapter} model=${brainConfig.model} threshold=${brainConfig.confidenceThreshold}`,
    );

    if (this.brain instanceof MockBrainAdapter) {
      this.brain.loadProfile(
        'roofr-estimate',
        join(configDir, 'poc', 'roofr-estimate.brain.yml'),
      );
      this.brain.loadProfile(
        'state-machine',
        join(configDir, 'poc', 'state-machine.brain.yml'),
      );
      this.brain.loadProfile(
        'transfer-human',
        join(configDir, 'poc', 'transfer-human.brain.yml'),
      );
      this.brain.loadProfile(
        'pause-resume',
        join(configDir, 'poc', 'pause-resume.brain.yml'),
      );
      const profile = process.env.POC_BRAIN_PROFILE ?? 'roofr-estimate';
      this.brain.setActiveProfile(profile);
    }
  }
}
