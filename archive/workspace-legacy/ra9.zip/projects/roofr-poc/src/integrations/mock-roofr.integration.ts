/**
 * Mock Roofr API integrations used by the estimate call flow.
 * Real HTTP can replace these later without changing Nodes.
 */

export interface RoofrAddressMatch {
  id: string;
  label: string;
}

export interface RoofrBookingResult {
  ok: true;
  confirmationId: string;
  slot: string;
  address: string;
}

const sleep = (ms: number) =>
  new Promise((r) =>
    setTimeout(
      r,
      process.env.MOCK_ROOFR_FAST === '1' ? Math.min(ms, 20) : ms,
    ),
  );

export async function resolveAddressFromText(
  _query: string,
): Promise<RoofrAddressMatch[]> {
  // Emulate geocoder / Roofr address resolve latency lightly.
  await sleep(400);
  return [
    { id: 'addr-1', label: '123 Main Street, Toronto, Ontario' },
    { id: 'addr-2', label: '3123 Main Street, Toronto, Ontario' },
  ];
}

export async function fetchAppointmentAvailability(
  _dayHint: string,
): Promise<string[]> {
  await sleep(3000);
  return ['9am', '10am', '11am'];
}

export async function bookAppointment(input: {
  slot: string;
  address: string;
  firstName?: string;
  lastName?: string;
}): Promise<RoofrBookingResult> {
  await sleep(3000);
  return {
    ok: true,
    confirmationId: `BK-${Date.now()}`,
    slot: input.slot,
    address: input.address,
  };
}

export function computeInstantEstimate(input: {
  timeline?: string;
  roofSlope?: string;
}): { low: number; high: number } {
  // Deterministic PoC range from the script.
  void input;
  return { low: 10_000, high: 15_000 };
}
