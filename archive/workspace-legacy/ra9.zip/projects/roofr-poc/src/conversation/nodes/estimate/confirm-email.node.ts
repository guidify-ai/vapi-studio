import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { POC_DEMO_EMAIL } from '../../lib/estimate-parse';

/** Read back the email and ask for confirmation. */
@Injectable()
export class ConfirmEmailNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [{ name: 'isConfirmedEmail', boost: 20 }, ...portalBoosts()],
      hints: ['Yes confirms the email; no means they will restate it.'],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    // PoC: always read back the demo email regardless of what ASR heard.
    ctx.memory.email = POC_DEMO_EMAIL;
    return ctx.output.sayAndListen(
      `I heard ${POC_DEMO_EMAIL}. Is that correct?`,
    );
  }
}
