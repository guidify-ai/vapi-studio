import type {
  ListenExtractField,
  ListenExtractSpec,
  SayAndListenOptions,
} from '../conversation/listen-expectation';

export type OutputKind =
  | 'say'
  | 'sayAndListen'
  | 'endCall'
  | 'transferToHuman';

export interface OutputAction {
  kind: OutputKind;
  text?: string;
  destination?: string;
  /** Present when sayAndListen declared listen/extract for the next answer. */
  sayAndListen?: SayAndListenOptions;
}

export type NodeResult = OutputAction;

export interface ConversationOutput {
  say(text: string): Promise<void>;
  sayAndListen(
    text: string,
    options?: SayAndListenOptions,
  ): Promise<NodeResult>;
  endCall(text?: string): Promise<NodeResult>;
  transferToHuman(destination?: string): Promise<NodeResult>;
  readonly actions: OutputAction[];
}

export class BufferedConversationOutput implements ConversationOutput {
  readonly actions: OutputAction[] = [];
  private readonly onSay?: (text: string) => Promise<void>;

  constructor(onSay?: (text: string) => Promise<void>) {
    this.onSay = onSay;
  }

  async say(text: string): Promise<void> {
    this.actions.push({ kind: 'say', text });
    if (this.onSay) {
      await this.onSay(text);
    }
  }

  async sayAndListen(
    text: string,
    options?: SayAndListenOptions,
  ): Promise<NodeResult> {
    const action: OutputAction = {
      kind: 'sayAndListen',
      text,
      sayAndListen: options,
    };
    this.actions.push(action);
    if (this.onSay) {
      await this.onSay(text);
    }
    return action;
  }

  async endCall(text?: string): Promise<NodeResult> {
    const action: OutputAction = { kind: 'endCall', text };
    this.actions.push(action);
    if (text && this.onSay) {
      await this.onSay(text);
    }
    return action;
  }

  async transferToHuman(destination?: string): Promise<NodeResult> {
    const action: OutputAction = { kind: 'transferToHuman', destination };
    this.actions.push(action);
    return action;
  }
}

/** Re-export for callers that import extract types via output. */
export type { ListenExtractField, ListenExtractSpec, SayAndListenOptions };
