import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../../roofr-variables';
import { portalBoosts } from '../../lib/portal-boosts';
import { looksLikeDayOrTimePreference } from '../../lib/estimate-parse';
import { listedChoiceListen, openListedChoice } from '../../lib/listed-choice-listen';
import { fetchAppointmentAvailability } from '../../../integrations/mock-roofr.integration';

/** User named a day/time preference — emulate availability check (~3s). */
@Injectable()
export class CheckAvailabilityNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return listedChoiceListen(ctx.memory.listedChoice);
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const text = ctx.userText.trim();
    if (!looksLikeDayOrTimePreference(text)) {
      ctx.runtime.brainSequenceIndex = Math.max(
        0,
        ctx.runtime.brainSequenceIndex - 1,
      );
      return ctx.output.sayAndListen(
        'What day or time works best for you?',
        {
          intentions: [
            { name: 'isRequestedAppointment', boost: 20 },
            ...portalBoosts(),
          ],
          hints: [
            'Caller says when they want an appointment (e.g. tomorrow, Friday morning).',
          ],
        },
      );
    }

    ctx.memory.appointmentDayHint = text;
    await ctx.output.say(
      "Okay — I'm checking availability with our scheduling system.",
    );
    const slots = await fetchAppointmentAvailability(
      ctx.memory.appointmentDayHint,
    );
    ctx.memory.availableSlots = slots;
    const choice = openListedChoice(ctx, {
      intro: 'I have several openings:',
      labels: slots,
      pickIntention: 'isSelectedAppointmentSlot',
      rejectIntention: 'isRejectedAppointmentSlot',
    });
    return ctx.output.sayAndListen(choice.text, choice.listen);
  }
}
