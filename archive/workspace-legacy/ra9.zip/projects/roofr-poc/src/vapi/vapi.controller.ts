import {
  Body,
  Controller,
  Headers,
  HttpCode,
  Post,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import type { Request, Response } from 'express';
import {
  CallTurnQueueRegistry,
  ConversationBootstrapService,
  EventService,
  ProviderIngressRepository,
  Supervisor,
  SupervisedConversationRegistry,
  VapiSseCompiler,
  extractNewestUserText,
  extractVapiCallId,
  extractVapiCallerNumber,
  listenTimeoutSecondsToMs,
  rememberCallerPhone,
} from '@guidify-ai/ra9';
import { VapiWebhookGuard } from './vapi.guard';
import { VapiWebhookHandler } from './vapi.handler';
import { brainConfig } from '../brain/brain.config';

@Controller('vapi')
export class VapiController {
  constructor(
    private readonly webhookHandler: VapiWebhookHandler,
    private readonly registry: SupervisedConversationRegistry,
    private readonly bootstrap: ConversationBootstrapService,
    private readonly supervisor: Supervisor,
    private readonly events: EventService,
    private readonly ingress: ProviderIngressRepository,
    private readonly turnQueues: CallTurnQueueRegistry,
  ) {}

  @Post('webhook')
  @HttpCode(200)
  @UseGuards(VapiWebhookGuard)
  async webhook(@Body() body: Record<string, unknown>) {
    const result = await this.webhookHandler.handle(body);
    return result.body ?? { ok: true };
  }

  @Post('chat/completions')
  async chatCompletions(
    @Body() body: Record<string, unknown>,
    @Headers() headers: Record<string, string | string[] | undefined>,
    @Req() req: Request,
    @Res() res: Response,
  ): Promise<void> {
    const callId =
      extractVapiCallId(body) ??
      (typeof headers['x-call-id'] === 'string' ? headers['x-call-id'] : null) ??
      (typeof headers['x-vapi-call-id'] === 'string'
        ? headers['x-vapi-call-id']
        : null);
    const callerPhoneNumber = extractVapiCallerNumber(body);
    if (callId && callerPhoneNumber) {
      rememberCallerPhone(callId, callerPhoneNumber);
    }

    const ingressRow = await this.ingress.record({
      kind: 'custom-llm',
      path: '/vapi/chat/completions',
      providerCallId: callId,
      messageType: 'chat.completions',
      headers: headers as Record<string, unknown>,
      body,
    });

    this.events.log('info', 'CUSTOM_LLM_REQUEST', {
      callId,
      ingressId: ingressRow.id,
      headerKeys: Object.keys(headers),
      bodyKeys: Object.keys(body),
      hasMessages: Array.isArray(body.messages),
      callerPhoneNumber,
    });

    if (!callId) {
      await this.ingress.setResponse(ingressRow.id, 400, {
        error: 'missing_call_id',
      });
      res.status(400).json({
        error: 'missing_call_id',
        message:
          'Could not correlate Custom LLM request to a Vapi call id. Logged body/header keys for operator inspection.',
      });
      return;
    }

    // Static Vapi assistants often skip assistant-request; bootstrap lazily.
    let runtime = this.registry.getByProviderCallId(callId);
    if (callerPhoneNumber && runtime) {
      runtime.metadata.callerPhoneNumber = callerPhoneNumber;
    }
    if (!runtime) {
      const brainProfileId = process.env.POC_BRAIN_PROFILE || 'roofr-estimate';
      runtime = await this.bootstrap.bootstrap({
        providerCallId: callId,
        brainProfileId,
        metadata: {
          messageType: 'custom-llm-lazy-bootstrap',
          brainProfileId,
          ...(callerPhoneNumber ? { callerPhoneNumber } : {}),
        },
      });
      this.events.log('info', 'CUSTOM_LLM_LAZY_BOOTSTRAP', {
        providerCallId: callId,
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        brainProfileId,
      });
    }

    const userText = extractNewestUserText(
      body as { messages?: Array<{ role?: string; content?: unknown }> },
    );
    const queue = this.turnQueues.get(callId);

    if (queue.isWorking) {
      this.events.log('info', 'CUSTOM_LLM_TURN_QUEUED', {
        providerCallId: callId,
        conversationId: runtime.conversationId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        userText,
        pendingCount: queue.pendingCount + (userText.trim() ? 1 : 0),
      });
    }

    let aborted = false;
    const interruptible =
      runtime.listenExpectation?.interruptible !== false;
    req.on('close', () => {
      // `close` also fires after a normal res.end — only treat as abort if
      // Vapi dropped this HTTP request before we finished the SSE.
      if (res.writableEnded) {
        return;
      }
      if (!interruptible) {
        this.events.log('info', 'CUSTOM_LLM_OVERLAP', {
          providerCallId: callId,
          runtimeInstanceId: runtime.runtimeInstanceId,
          note: 'uninterruptible listen — overlapping POST queued, not aborted',
        });
        return;
      }
      aborted = true;
      runtime.turn.interrupted = true;
      runtime.turn.lastInterruptAt = new Date().toISOString();
      this.events.log('info', 'CUSTOM_LLM_ABORT', {
        providerCallId: callId,
        runtimeInstanceId: runtime.runtimeInstanceId,
      });
    });

    try {
      if (!res.headersSent) {
        res.status(200);
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
      }

      const uninterruptibleHold =
        runtime.listenExpectation?.interruptible === false &&
        runtime.openingCompleted;
      const useListenHold =
        uninterruptibleHold ||
        (brainConfig.adapter === 'mock' && runtime.openingCompleted);
      const outcome = await queue.runExclusive({
        userText,
        listenHoldMs: useListenHold
          ? listenTimeoutSecondsToMs(
              runtime.listenExpectation?.timeoutSeconds,
            )
          : 0,
        // Each Custom LLM POST must speak on its own SSE. Vapi plays the
        // latest request — draining waiters onto this older connection is
        // dead air on the phone.
        continueDraining: () => false,
        work: async (combinedUserText, meta) => {
          this.events.log('info', 'CUSTOM_LLM_TURN', {
            providerCallId: callId,
            conversationId: runtime.conversationId,
            runtimeInstanceId: runtime.runtimeInstanceId,
            userText: combinedUserText,
            series: meta.series,
            parts: meta.parts,
            turnNumber: runtime.turn.turnNumber + 1,
            memory: { ...runtime.memory },
          });

          if (!res.headersSent) {
            res.status(200);
            res.setHeader('Content-Type', 'text/event-stream');
            res.setHeader('Cache-Control', 'no-cache');
            res.setHeader('Connection', 'keep-alive');
          }

          const compiler = new VapiSseCompiler({ tools: body.tools });
          const writer = {
            write: (chunk: string) => {
              if (!aborted) {
                res.write(chunk);
              }
            },
            end: () => {
              /* leader ends once below */
            },
          };

          runtime.lastAssistantSpeech = [];
          const turn = await this.supervisor.handleTurn({
            runtime,
            userText: combinedUserText,
            onSay: async (text) => {
              runtime.lastAssistantSpeech.push(text);
              if (aborted) {
                return;
              }
              this.events.log('info', 'SAY', {
                providerCallId: callId,
                runtimeInstanceId: runtime.runtimeInstanceId,
                text,
                turnNumber: runtime.turn.turnNumber,
              });
              compiler.writeAssistantText(writer, text);
            },
          });

          if (aborted) {
            return { aborted: true as const, turn };
          }

          const { emittedTools } = await compiler.streamTerminalActions(
            writer,
            turn.actions,
          );
          if (emittedTools.length > 0) {
            this.events.log('info', 'TOOL_CALL_EMITTED', {
              providerCallId: callId,
              runtimeInstanceId: runtime.runtimeInstanceId,
              emittedTools,
              advertisedTools: Array.isArray(body.tools) ? body.tools : [],
            });
          }

          return {
            aborted: false as const,
            turn,
            emittedTools,
          };
        },
      });

      if (outcome.status === 'skipped') {
        const replay = [...runtime.lastAssistantSpeech];
        this.events.log('info', 'CUSTOM_LLM_TURN_SKIPPED', {
          providerCallId: callId,
          conversationId: runtime.conversationId,
          runtimeInstanceId: runtime.runtimeInstanceId,
          userText,
          reason: 'coalesced_by_leader',
          replayed: replay.length,
        });
        await this.ingress.setResponse(ingressRow.id, 200, {
          skipped: true,
          reason: 'coalesced_by_leader',
          replayed: replay.length,
        });
        if (!res.headersSent) {
          res.status(200);
          res.setHeader('Content-Type', 'text/event-stream');
          res.setHeader('Cache-Control', 'no-cache');
          res.setHeader('Connection', 'keep-alive');
        }
        const compiler = new VapiSseCompiler({ tools: body.tools });
        const writer = {
          write: (chunk: string) => {
            res.write(chunk);
          },
          end: () => {
            if (!res.writableEnded) res.end();
          },
        };
        compiler.replayAssistantSpeech(writer, replay);
        await compiler.streamTerminalActions(writer, []);
        writer.end();
        return;
      }

      const result = outcome.result;
      if (result.aborted) {
        await this.ingress.setResponse(ingressRow.id, 499, { aborted: true });
        if (!res.writableEnded) res.end();
        return;
      }

      await this.ingress.setResponse(ingressRow.id, 200, {
        streamed: true,
        selectedNodeId: result.turn.selectedNodeId,
        selectedClass: result.turn.selectedClass,
        intentionNames: result.turn.intentionNames,
        actions: result.turn.actions,
        emittedTools: result.emittedTools,
      });
      if (!res.writableEnded) res.end();
    } catch (error) {
      this.events.log('error', 'CUSTOM_LLM_ERROR', {
        providerCallId: callId,
        runtimeInstanceId: runtime.runtimeInstanceId,
        error: error instanceof Error ? error.message : String(error),
      });
      await this.ingress.setResponse(ingressRow.id, 500, {
        error: error instanceof Error ? error.message : String(error),
      });
      if (!res.headersSent) {
        res.status(500).json({ error: 'turn_failed' });
      } else if (!res.writableEnded) {
        res.end();
      }
    }
  }
}
