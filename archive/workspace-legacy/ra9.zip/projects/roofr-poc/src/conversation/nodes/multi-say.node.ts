import { Injectable } from '@nestjs/common';
import {
  Ra9Node,
  RA9_INTENTIONS,
  type ListenExpectation,
  type NodeContext,
  type NodeResult,
} from '@guidify-ai/ra9';
import type { RoofrConversationSchema } from '../roofr-variables';

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

@Injectable()
export class MultiSayNode extends Ra9Node<RoofrConversationSchema> {
  async listen(
    _ctx: NodeContext<RoofrConversationSchema>,
  ): Promise<ListenExpectation> {
    return {
      intentions: [
        { name: 'isInterruptTest', boost: 20 },
        { name: RA9_INTENTIONS.isMad, boost: 15 },
        { name: RA9_INTENTIONS.isPause, boost: 8 },
        { name: RA9_INTENTIONS.isGoodbye, boost: 5 },
      ],
      hints: [
        'User may say continue / go on / what next after the multi-say demo.',
        'If they say wait/hold on, prefer pause.',
        'If angry/frustrated, prefer ra9.isMad.',
        'ASR: "interrupt" may arrive as "in a rupt" / "enter up".',
      ],
    };
  }

  async run(ctx: NodeContext<RoofrConversationSchema>): Promise<NodeResult> {
    const name = ctx.memory.callerName?.trim();
    await ctx.output.say(
      name ? `Thanks, ${name}. Give me a moment.` : 'Okay, give me a moment.',
    );
    await sleep(4000);
    await ctx.output.say('Got it, I have some data for you.');
    await sleep(4000);
    return ctx.output.sayAndListen(
      'Here it is. This proves I can send multiple messages during one turn.',
    );
  }
}
